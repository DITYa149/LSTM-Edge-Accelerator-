`timescale 1ns/1ps
// =============================================================================
// FSM_Controller.v  -  control FSM + loop sequencer for the LSTM accelerator
//
// Implements the "Control FSM: start/done, gate/head select" block of the diagram.
// One shared MAC is time-multiplexed over: 4 LSTM gates -> shared dense -> 4 sensor heads.
//
// Schedule for ONE inference (all counters are inside this module):
//
//   INIT                      clear h/c state
//   for t = 0 .. TIME_STEPS-1
//       LOADX                 read the 4 features of sample t from the input window
//       for n = 0 .. 15       (neuron)
//           for g = F,I,G,O   (gate)
//               GATE_MAC      20 elements: x[0..3] then h[0..15], bias at element 0, ONE rounding
//               GATE_WAIT     mac_done -> activation (sigmoid / tanh) captured into gate register
//           CELL              c[n]    = f*c[n] + i*g
//           TANH              tanh(c[n]) captured
//           HIDDEN            h_new[n] = o * tanh(c[n])
//       COMMIT                h <= h_new   (all 16 neurons at once, so U*h always uses the OLD h)
//   for n = 0 .. 15           DENSE_MAC / DENSE_WAIT   16 elements -> PReLU -> dense register
//   for j = 0 .. 3            HEAD_MAC  / HEAD_WAIT    16 elements -> prediction register
//   OUTPUT_STORE              prediction -> output buffer
//   SUMMARY                   rule-based comparators latched
//   NEXT                      pred_valid strobe; more rollout steps?
//   ROLL                      write the 4 predicted values over the oldest window sample,
//                             advance the circular window base ("loops back as next xt")
//   DONE
//
// mac_start is a ONE-CYCLE pulse coincident with the first valid element (what the MAC needs).
// =============================================================================
module fsm_controller #(
    parameter TIME_STEPS    = 10,
    parameter INPUT_SIZE    = 4,      // must be <= 4 (x_capture_idx is 2 bits)
    parameter HIDDEN_SIZE   = 16,
    parameter DENSE_SIZE    = 16,
    parameter HEAD_COUNT    = 4,
    parameter ROLLOUT_STEPS = 10      // 1 = single prediction, N = autoregressive N-step forecast
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        start,
    input  wire        mac_done,

    // status
    output wire        busy,
    output wire        done,
    output wire        pred_valid,      // 1 cycle: prediction / summary registers hold a new result
    output wire [3:0]  time_step,
    output wire [7:0]  rollout_idx,

    // input window access
    output wire        input_read_en,
    output wire [5:0]  input_read_addr,
    output wire        x_capture_en,
    output wire [1:0]  x_capture_idx,
    output wire        window_write_en,
    output wire [5:0]  window_write_addr,
    output wire [1:0]  window_write_idx,

    // MAC sequencing
    output wire        mac_start,       // 1-cycle pulse with the first element
    output wire        mac_valid,
    output wire        mac_last,
    output wire [1:0]  phase,           // 0 = LSTM gate, 1 = shared dense, 2 = sensor head
    output wire [1:0]  gate_sel,        // 0 = F, 1 = I, 2 = G (candidate), 3 = O
    output wire [5:0]  unit_idx,        // neuron (LSTM / dense) or head (0..3)
    output wire [5:0]  elem_idx,        // element inside the dot product

    // datapath strobes
    output wire        clear_state,     // zero h and c
    output wire        run_clear,       // first INIT of a run: empty the output buffer
    output wire        gate_capture_en,
    output wire        cell_update_en,
    output wire        tanh_capture_en,
    output wire        hidden_update_en,
    output wire        commit_h_en,
    output wire        dense_capture_en,
    output wire        head_capture_en,
    output wire        output_store_en,
    output wire        summary_en
);

    // ------------------------------------------------------------------ constants
    localparam integer LSTM_LAST      = INPUT_SIZE + HIDDEN_SIZE - 1;
    localparam integer DENSE_IN_LAST  = HIDDEN_SIZE - 1;
    localparam integer HEAD_IN_LAST   = DENSE_SIZE - 1;
    localparam integer WINDOW_WORDS   = TIME_STEPS * INPUT_SIZE;

    localparam [1:0] PHASE_LSTM  = 2'd0;
    localparam [1:0] PHASE_DENSE = 2'd1;
    localparam [1:0] PHASE_HEAD  = 2'd2;

    localparam [4:0] S_IDLE         = 5'd0,
                     S_INIT         = 5'd1,
                     S_LOADX        = 5'd2,
                     S_GATE_MAC     = 5'd3,
                     S_GATE_WAIT    = 5'd4,
                     S_CELL         = 5'd5,
                     S_TANH         = 5'd6,
                     S_HIDDEN       = 5'd7,
                     S_COMMIT       = 5'd8,
                     S_DENSE_MAC    = 5'd9,
                     S_DENSE_WAIT   = 5'd10,
                     S_HEAD_MAC     = 5'd11,
                     S_HEAD_WAIT    = 5'd12,
                     S_OUTPUT_STORE = 5'd13,
                     S_SUMMARY      = 5'd14,
                     S_NEXT         = 5'd15,
                     S_ROLL         = 5'd16,
                     S_DONE         = 5'd17;

    reg [4:0] state;

    reg [3:0] r_t;              // time step
    reg [5:0] r_unit;
    reg [1:0] r_gate;
    reg [5:0] r_elem;
    reg [7:0] r_roll;           // rollout step
    reg [5:0] samp_base;        // word address of sample t inside the circular window
    reg [5:0] win_base;         // word address of the oldest sample (logical sample 0)

    // circular-window address advance
    function [5:0] next_base;
        input [5:0] b;
        begin
            if (b + INPUT_SIZE >= WINDOW_WORDS) next_base = 6'd0;
            else                                next_base = b + INPUT_SIZE;
        end
    endfunction

    // ------------------------------------------------------------------ state register
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state     <= S_IDLE;
            r_t       <= 4'd0;
            r_unit    <= 6'd0;
            r_gate    <= 2'd0;
            r_elem    <= 6'd0;
            r_roll    <= 8'd0;
            samp_base <= 6'd0;
            win_base  <= 6'd0;
        end else begin
            case (state)
                S_IDLE: begin
                    if (start) begin
                        win_base <= 6'd0;       // logical sample 0 == memory word 0 at the start of a run
                        r_roll   <= 8'd0;
                        state    <= S_INIT;
                    end
                end

                S_INIT: begin
                    r_t       <= 4'd0;
                    r_unit    <= 6'd0;
                    r_gate    <= 2'd0;
                    r_elem    <= 6'd0;
                    samp_base <= win_base;
                    state     <= S_LOADX;
                end

                // r_elem = 0..INPUT_SIZE : reads issued for 0..INPUT_SIZE-1, captures for 1..INPUT_SIZE
                S_LOADX: begin
                    if (r_elem == INPUT_SIZE) begin
                        r_elem <= 6'd0;
                        r_unit <= 6'd0;
                        r_gate <= 2'd0;
                        state  <= S_GATE_MAC;
                    end else begin
                        r_elem <= r_elem + 6'd1;
                    end
                end

                S_GATE_MAC: begin
                    if (r_elem == LSTM_LAST) begin
                        r_elem <= 6'd0;
                        state  <= S_GATE_WAIT;
                    end else begin
                        r_elem <= r_elem + 6'd1;
                    end
                end

                S_GATE_WAIT: begin
                    if (mac_done) begin
                        if (r_gate == 2'd3) begin
                            r_gate <= 2'd0;
                            state  <= S_CELL;
                        end else begin
                            r_gate <= r_gate + 2'd1;
                            state  <= S_GATE_MAC;
                        end
                    end
                end

                S_CELL:  state <= S_TANH;
                S_TANH:  state <= S_HIDDEN;

                S_HIDDEN: begin
                    if (r_unit == HIDDEN_SIZE - 1) begin
                        r_unit <= 6'd0;
                        state  <= S_COMMIT;
                    end else begin
                        r_unit <= r_unit + 6'd1;
                        state  <= S_GATE_MAC;
                    end
                end

                S_COMMIT: begin
                    if (r_t == TIME_STEPS - 1) begin
                        r_unit <= 6'd0;
                        r_elem <= 6'd0;
                        state  <= S_DENSE_MAC;
                    end else begin
                        r_t       <= r_t + 4'd1;
                        samp_base <= next_base(samp_base);
                        r_elem    <= 6'd0;
                        state     <= S_LOADX;
                    end
                end

                S_DENSE_MAC: begin
                    if (r_elem == DENSE_IN_LAST) begin
                        r_elem <= 6'd0;
                        state  <= S_DENSE_WAIT;
                    end else begin
                        r_elem <= r_elem + 6'd1;
                    end
                end

                S_DENSE_WAIT: begin
                    if (mac_done) begin
                        if (r_unit == DENSE_SIZE - 1) begin
                            r_unit <= 6'd0;
                            state  <= S_HEAD_MAC;
                        end else begin
                            r_unit <= r_unit + 6'd1;
                            state  <= S_DENSE_MAC;
                        end
                    end
                end

                S_HEAD_MAC: begin
                    if (r_elem == HEAD_IN_LAST) begin
                        r_elem <= 6'd0;
                        state  <= S_HEAD_WAIT;
                    end else begin
                        r_elem <= r_elem + 6'd1;
                    end
                end

                S_HEAD_WAIT: begin
                    if (mac_done) begin
                        if (r_unit == HEAD_COUNT - 1) begin
                            r_unit <= 6'd0;
                            state  <= S_OUTPUT_STORE;
                        end else begin
                            r_unit <= r_unit + 6'd1;
                            state  <= S_HEAD_MAC;
                        end
                    end
                end

                S_OUTPUT_STORE: state <= S_SUMMARY;
                S_SUMMARY:      state <= S_NEXT;

                S_NEXT: begin
                    if (r_roll == ROLLOUT_STEPS - 1) begin
                        state <= S_DONE;
                    end else begin
                        r_roll <= r_roll + 8'd1;
                        r_elem <= 6'd0;
                        state  <= S_ROLL;
                    end
                end

                S_ROLL: begin
                    if (r_elem == INPUT_SIZE - 1) begin
                        win_base <= next_base(win_base);
                        r_elem   <= 6'd0;
                        state    <= S_INIT;
                    end else begin
                        r_elem <= r_elem + 6'd1;
                    end
                end

                S_DONE: state <= S_IDLE;

                default: state <= S_IDLE;
            endcase
        end
    end

    // ------------------------------------------------------------------ decoded outputs (Moore)
    wire in_gate_mac   = (state == S_GATE_MAC);
    wire in_dense_mac  = (state == S_DENSE_MAC);
    wire in_head_mac   = (state == S_HEAD_MAC);

    assign busy        = (state != S_IDLE) && (state != S_DONE);
    assign done        = (state == S_DONE);
    assign pred_valid  = (state == S_NEXT);
    assign time_step   = r_t;
    assign rollout_idx = r_roll;

    assign input_read_en     = (state == S_LOADX) && (r_elem < INPUT_SIZE);
    assign input_read_addr   = samp_base + r_elem;
    assign x_capture_en      = (state == S_LOADX) && (r_elem >= 6'd1);
    assign x_capture_idx     = r_elem[1:0] - 2'd1;
    assign window_write_en   = (state == S_ROLL);
    assign window_write_addr = win_base + r_elem;
    assign window_write_idx  = r_elem[1:0];

    assign mac_valid = in_gate_mac | in_dense_mac | in_head_mac;
    assign mac_start = mac_valid && (r_elem == 6'd0);
    assign mac_last  = (in_gate_mac  && (r_elem == LSTM_LAST))     ||
                       (in_dense_mac && (r_elem == DENSE_IN_LAST)) ||
                       (in_head_mac  && (r_elem == HEAD_IN_LAST));

    assign phase    = (state == S_DENSE_MAC || state == S_DENSE_WAIT) ? PHASE_DENSE :
                      (state == S_HEAD_MAC  || state == S_HEAD_WAIT)  ? PHASE_HEAD  :
                                                                         PHASE_LSTM;
    assign gate_sel = r_gate;
    assign unit_idx = r_unit;
    assign elem_idx = r_elem;

    assign clear_state      = (state == S_INIT);
    assign run_clear        = (state == S_INIT) && (r_roll == 8'd0);
    assign gate_capture_en  = (state == S_GATE_WAIT)  && mac_done;
    assign cell_update_en   = (state == S_CELL);
    assign tanh_capture_en  = (state == S_TANH);
    assign hidden_update_en = (state == S_HIDDEN);
    assign commit_h_en      = (state == S_COMMIT);
    assign dense_capture_en = (state == S_DENSE_WAIT) && mac_done;
    assign head_capture_en  = (state == S_HEAD_WAIT)  && mac_done;
    assign output_store_en  = (state == S_OUTPUT_STORE);
    assign summary_en       = (state == S_SUMMARY);

endmodule
