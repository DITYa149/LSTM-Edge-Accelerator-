// =============================================================================
// Mac_Engine.v  -  single shared multiply-accumulate unit (UNCHANGED LOGIC)
//
// Usage contract (important for the sequencer that drives it):
//   * `start` must be a ONE-CYCLE pulse, asserted together with the FIRST valid element
//     of a dot product.  (If `start` is held high the bias is re-loaded on every
//     element and the accumulation is destroyed.)
//   * `valid` is high for every element, `last` marks the final element.
//   * One rounding + saturation to Q3.12 happens at `last`; `done` pulses the cycle
//     after `last`, with `result` valid in that same cycle.
//   * result = round_half_away( bias<<12 + sum(data*weight) ) , saturated to 16 bit.
// =============================================================================
`timescale 1ns/1ps

module mac_engine #(
    parameter DATA_WIDTH      = 16,
    parameter ACC_WIDTH       = 40,
    parameter FRACTIONAL_BITS = 12
)(
    input  wire                         clk,
    input  wire                         rst,

    input  wire                         start,
    input  wire                         valid,
    input  wire                         last,

    input  wire signed [DATA_WIDTH-1:0] data_in,
    input  wire signed [DATA_WIDTH-1:0] weight_in,
    input  wire signed [DATA_WIDTH-1:0] bias_in,

    output reg signed [ACC_WIDTH-1:0]   result,
    output reg                          done
);

    reg signed [ACC_WIDTH-1:0] accumulator;
    wire signed [(2*DATA_WIDTH)-1:0] product_full;
    wire signed [ACC_WIDTH-1:0] product_extended;
    wire signed [ACC_WIDTH-1:0] bias_extended;
    wire signed [ACC_WIDTH-1:0] bias_term;
    wire signed [ACC_WIDTH-1:0] base_accumulator;
    wire signed [ACC_WIDTH-1:0] sum_next;
    wire signed [DATA_WIDTH-1:0] scaled_result;

    assign product_full = $signed(data_in) * $signed(weight_in);

    assign product_extended =
        {{(ACC_WIDTH-(2*DATA_WIDTH)){product_full[(2*DATA_WIDTH)-1]}},
          product_full};

    assign bias_extended =
        {{(ACC_WIDTH-DATA_WIDTH){bias_in[DATA_WIDTH-1]}}, bias_in};

    assign bias_term = bias_extended <<< FRACTIONAL_BITS;
    assign base_accumulator = start ? bias_term : accumulator;
    assign sum_next = base_accumulator + product_extended;

    function signed [DATA_WIDTH-1:0] round_and_saturate;
        input signed [ACC_WIDTH-1:0] value;

        reg signed [ACC_WIDTH-1:0] magnitude;
        reg signed [ACC_WIDTH-1:0] rounded_magnitude;
        reg signed [ACC_WIDTH-1:0] half_lsb;
        reg signed [ACC_WIDTH-1:0] positive_max;
        reg signed [ACC_WIDTH-1:0] negative_limit;

        begin
            half_lsb = 0;
            if (FRACTIONAL_BITS > 0)
                half_lsb = ({{(ACC_WIDTH-1){1'b0}}, 1'b1}
                            <<< (FRACTIONAL_BITS-1));

            positive_max = ({{(ACC_WIDTH-1){1'b0}}, 1'b1}
                            <<< (DATA_WIDTH-1)) - 1'b1;
            negative_limit = ({{(ACC_WIDTH-1){1'b0}}, 1'b1}
                              <<< (DATA_WIDTH-1));

            magnitude = value[ACC_WIDTH-1] ? -value : value;
            rounded_magnitude =
                (magnitude + half_lsb) >>> FRACTIONAL_BITS;

            if (!value[ACC_WIDTH-1]) begin
                if (rounded_magnitude > positive_max)
                    round_and_saturate = {1'b0, {(DATA_WIDTH-1){1'b1}}};
                else
                    round_and_saturate = rounded_magnitude[DATA_WIDTH-1:0];
            end else begin
                if (rounded_magnitude > negative_limit)
                    round_and_saturate = {1'b1, {(DATA_WIDTH-1){1'b0}}};
                else
                    round_and_saturate = -rounded_magnitude[DATA_WIDTH-1:0];
            end
        end
    endfunction

    assign scaled_result = round_and_saturate(sum_next);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            accumulator <= 0;
            result      <= 0;
            done        <= 1'b0;
        end else begin
            done <= 1'b0;

            if (valid) begin
                if (last) begin
                    result <=
                        {{(ACC_WIDTH-DATA_WIDTH){scaled_result[DATA_WIDTH-1]}},
                          scaled_result};
                    done <= 1'b1;
                end else begin
                    accumulator <= sum_next;
                end
            end else if (start) begin
                accumulator <= bias_term;
            end
        end
    end

endmodule
