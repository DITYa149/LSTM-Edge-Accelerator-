`timescale 1ns/1ps
// =============================================================================
// Prelu.v - PReLU for ONE neuron:  y = x            (x >= 0)
//                                  y = q(alpha * x) (x <  0)
// Scalar on purpose: the diagram shares one MAC/dense path, so the 16 neurons are
// produced one at a time and the per-neuron alpha comes from a weight ROM.
// =============================================================================
module prelu #(
    parameter DATA_WIDTH      = 16,
    parameter FRACTIONAL_BITS = 12
)(
    input  wire signed [DATA_WIDTH-1:0] data_in,
    input  wire signed [DATA_WIDTH-1:0] alpha,
    output wire signed [DATA_WIDTH-1:0] data_out
);

    function signed [DATA_WIDTH-1:0] q_multiply;
        input signed [DATA_WIDTH-1:0] left;
        input signed [DATA_WIDTH-1:0] right;

        reg signed [(2*DATA_WIDTH)-1:0] product;
        reg signed [(2*DATA_WIDTH):0]   extended_product;
        reg        [(2*DATA_WIDTH):0]   magnitude;
        reg        [(2*DATA_WIDTH):0]   rounded_magnitude;
        reg signed [(2*DATA_WIDTH):0]   rounded_value;
        reg signed [(2*DATA_WIDTH):0]   positive_limit;
        reg signed [(2*DATA_WIDTH):0]   negative_limit;
        reg        [(2*DATA_WIDTH):0]   half_lsb;
        begin
            product = $signed(left) * $signed(right);
            extended_product = {product[(2*DATA_WIDTH)-1], product};

            if (extended_product < 0) magnitude = -extended_product;
            else                      magnitude =  extended_product;

            if (FRACTIONAL_BITS > 0) half_lsb = 1 << (FRACTIONAL_BITS-1);
            else                     half_lsb = 0;

            // round to nearest, exact halves away from zero
            rounded_magnitude = (magnitude + half_lsb) >> FRACTIONAL_BITS;

            if (extended_product < 0) rounded_value = -$signed(rounded_magnitude);
            else                      rounded_value =  $signed(rounded_magnitude);

            positive_limit =   (1 <<< (DATA_WIDTH-1)) - 1;
            negative_limit = -(1 <<< (DATA_WIDTH-1));

            if (rounded_value > positive_limit)
                q_multiply = {1'b0, {(DATA_WIDTH-1){1'b1}}};
            else if (rounded_value < negative_limit)
                q_multiply = {1'b1, {(DATA_WIDTH-1){1'b0}}};
            else
                q_multiply = rounded_value[DATA_WIDTH-1:0];
        end
    endfunction

    assign data_out = (data_in >= 0) ? data_in : q_multiply(alpha, data_in);

endmodule
