`timescale 1ns/1ps
// =============================================================================
// Data_Flow.v  -  top level of the LSTM environment-prediction accelerator
//
//   Weight ROMs -> shared MAC -> sigmoid/tanh LUT -> cell/hidden update
//        -> shared dense + PReLU -> 4 linear sensor heads -> output buffer
//        -> rule-based summary -> environment condition
//   with the Control FSM (FSM_Controller.v) steering every block and the output
//   looping back into the input window ("next xt", x ROLLOUT_STEPS).
//
// Numerics: Q3.12, 16-bit; every rounding is round-half-away-from-zero with saturation.
// Feature order everywhere: [0]=temperature [1]=solar [2]=humidity [3]=gas
//
// Host interface
//   1. (optional) while idle, load a 10x4 window through in_load_* (word address t*4+f),
//      or just rely on INPUT_FILE which preloads the window.
//   2. pulse `start` for one cycle.
//   3. pred_valid pulses once per prediction (ROLLOUT_STEPS times) with `prediction`,
//      `env_state`, `env_flags` valid in that cycle.  `done` pulses at the end of the run.
//   4. out_rd_* reads the output buffer (newest prediction at address 9, sync read).
//
// Parameters
//   ROLLOUT_STEPS = 1  : one prediction from the 10-step window
//   ROLLOUT_STEPS = N  : autoregressive; each prediction replaces the oldest window sample
//   INPUT_MAJOR_WEIGHTS = 0 : W/U/dense .mem files are neuron-major (index = neuron*IN + input)
//                           1 : input-major (index = input*OUT + neuron)  e.g. a Keras kernel
//                               flattened row-major without transposing
//   MEM_DIR : directory (with trailing slash) that holds all .mem files
// =============================================================================
module data_flow #(
    parameter TIME_STEPS          = 10,
    parameter ROLLOUT_STEPS       = 1,
    parameter INPUT_MAJOR_WEIGHTS = 0,
    parameter MEM_DIR             = "mem/",
    parameter INPUT_FILE          = {MEM_DIR, "input_case_000.mem"}
)(
    input  wire               clk,
    input  wire               rst,
    input  wire               start,
    output wire               busy,
    output wire               done,

    // load a sample window while idle
    input  wire               in_load_en,
    input  wire [5:0]         in_load_addr,
    input  wire signed [15:0] in_load_data,

    // results
    output wire               pred_valid,
    output wire [63:0]        prediction,      // {gas, humidity, solar, temp}
    output wire [1:0]         env_state,       // 0 stable, 1 worsening, 2 hazardous, 3 barren
    output wire [13:0]        env_flags,

    // output buffer read port
    input  wire               out_rd_en,
    input  wire [3:0]         out_rd_addr,
    output wire [63:0]        out_rd_data,
    output wire [3:0]         out_count
);

    // ------------------------------------------------------------------ sizes / file names
    localparam INPUT_SIZE   = 4;
    localparam HIDDEN_SIZE  = 16;
    localparam DENSE_SIZE   = 16;
    localparam HEAD_COUNT   = 4;
    localparam WINDOW_WORDS = TIME_STEPS * INPUT_SIZE;

    localparam [1:0] PHASE_LSTM  = 2'd0;
    localparam [1:0] PHASE_DENSE = 2'd1;
    localparam [1:0] PHASE_HEAD  = 2'd2;

    // ---- edit these strings if your Python export uses different names ----------------
    localparam F_W_FORGET    = {MEM_DIR, "w_forget.mem"};
    localparam F_W_INPUT     = {MEM_DIR, "w_input.mem"};
    localparam F_W_CANDIDATE = {MEM_DIR, "w_candidate.mem"};
    localparam F_W_OUTPUT    = {MEM_DIR, "w_gate_output.mem"};
    localparam F_U_FORGET    = {MEM_DIR, "u_forget.mem"};
    localparam F_U_INPUT     = {MEM_DIR, "u_input.mem"};
    localparam F_U_CANDIDATE = {MEM_DIR, "u_candidate.mem"};
    localparam F_U_OUTPUT    = {MEM_DIR, "u_gate_output.mem"};
    localparam F_B_FORGET    = {MEM_DIR, "b_forget.mem"};
    localparam F_B_INPUT     = {MEM_DIR, "b_input.mem"};
    localparam F_B_CANDIDATE = {MEM_DIR, "b_candidate.mem"};
    localparam F_B_OUTPUT    = {MEM_DIR, "b_gate_output.mem"};
    localparam F_W_SHARED    = {MEM_DIR, "w_shared.mem"};
    localparam F_B_SHARED    = {MEM_DIR, "b_shared.mem"};
    localparam F_ALPHA       = {MEM_DIR, "alpha_prelu.mem"};
    localparam F_W_TEMP      = {MEM_DIR, "w_temp.mem"};
    localparam F_W_SOLAR     = {MEM_DIR, "w_solar.mem"};
    localparam F_W_HUMIDITY  = {MEM_DIR, "w_humidity.mem"};
    localparam F_W_GAS       = {MEM_DIR, "w_gas.mem"};
    localparam F_B_HEADS     = {MEM_DIR, "b_heads.mem"};
    localparam F_SIGMOID     = {MEM_DIR, "sigmoid_lut.mem"};
    localparam F_TANH        = {MEM_DIR, "tanh_lut.mem"};

    // ------------------------------------------------------------------ controller
    wire        mac_start, mac_valid, mac_last, mac_done;
    wire [1:0]  phase, gate_sel;
    wire [5:0]  unit_idx, elem_idx;
    wire        input_read_en, x_capture_en, window_write_en;
    wire [5:0]  input_read_addr, window_write_addr;
    wire [1:0]  x_capture_idx, window_write_idx;
    wire        clear_state, run_clear, gate_capture_en, cell_update_en, tanh_capture_en;
    wire        hidden_update_en, commit_h_en, dense_capture_en, head_capture_en;
    wire        output_store_en, summary_en;
    wire [3:0]  time_step;
    wire [7:0]  rollout_idx;

    fsm_controller #(
        .TIME_STEPS(TIME_STEPS), .INPUT_SIZE(INPUT_SIZE), .HIDDEN_SIZE(HIDDEN_SIZE),
        .DENSE_SIZE(DENSE_SIZE), .HEAD_COUNT(HEAD_COUNT), .ROLLOUT_STEPS(ROLLOUT_STEPS)
    ) u_fsm (
        .clk(clk), .rst(rst), .start(start), .mac_done(mac_done),
        .busy(busy), .done(done), .pred_valid(pred_valid),
        .time_step(time_step), .rollout_idx(rollout_idx),
        .input_read_en(input_read_en), .input_read_addr(input_read_addr),
        .x_capture_en(x_capture_en), .x_capture_idx(x_capture_idx),
        .window_write_en(window_write_en), .window_write_addr(window_write_addr),
        .window_write_idx(window_write_idx),
        .mac_start(mac_start), .mac_valid(mac_valid), .mac_last(mac_last),
        .phase(phase), .gate_sel(gate_sel), .unit_idx(unit_idx), .elem_idx(elem_idx),
        .clear_state(clear_state), .run_clear(run_clear),
        .gate_capture_en(gate_capture_en), .cell_update_en(cell_update_en),
        .tanh_capture_en(tanh_capture_en), .hidden_update_en(hidden_update_en),
        .commit_h_en(commit_h_en), .dense_capture_en(dense_capture_en),
        .head_capture_en(head_capture_en), .output_store_en(output_store_en),
        .summary_en(summary_en)
    );

    // ------------------------------------------------------------------ state registers
    reg signed [15:0] x_reg     [0:INPUT_SIZE-1];     // current sample
    reg signed [15:0] h_reg     [0:HIDDEN_SIZE-1];    // hidden state h(t-1)
    reg signed [15:0] h_new     [0:HIDDEN_SIZE-1];    // hidden state being built for h(t)
    reg signed [15:0] c_reg     [0:HIDDEN_SIZE-1];    // cell state
    reg signed [15:0] gate_reg  [0:3];                // activated F, I, G, O of the current neuron
    reg signed [15:0] tanh_reg;                       // tanh(c) of the current neuron
    reg signed [15:0] dense_reg [0:DENSE_SIZE-1];     // PReLU(dense) outputs
    reg        [63:0] pred_reg;                       // {gas, humidity, solar, temp}
    reg        [1:0]  summary_state_q;
    reg        [13:0] summary_flags_q;

    // ------------------------------------------------------------------ input window buffer
    wire signed [15:0] in_data_out;
    wire               ext_we   = in_load_en & ~busy;
    wire               in_we    = window_write_en | ext_we;
    wire [5:0]         in_waddr = window_write_en ? window_write_addr : in_load_addr;
    wire signed [15:0] in_wdata = window_write_en ? pred_reg[{window_write_idx, 4'b0000} +: 16]
                                                  : in_load_data;

    input_buffer #(.DATA_WIDTH(16), .ADDR_WIDTH(6), .DEPTH(WINDOW_WORDS), .MEM_FILE(INPUT_FILE))
    u_input_buffer (
        .clk(clk), .rst(rst),
        .write_en(in_we), .write_addr(in_waddr), .write_data(in_wdata),
        .read_en(input_read_en), .read_addr(input_read_addr), .data_out(in_data_out)
    );

    // ------------------------------------------------------------------ weight address generation
    wire [7:0] unit8 = {2'b00, unit_idx};
    wire [7:0] elem8 = {2'b00, elem_idx};
    wire [7:0] hj8   = elem8 - INPUT_SIZE;            // index into h while elem >= INPUT_SIZE
    wire       x_phase = (elem_idx < INPUT_SIZE);

    wire [7:0] w_addr_lstm = INPUT_MAJOR_WEIGHTS ? (elem8 * HIDDEN_SIZE + unit8)
                                                 : (unit8 * INPUT_SIZE  + elem8);
    wire [7:0] u_addr_lstm = INPUT_MAJOR_WEIGHTS ? (hj8   * HIDDEN_SIZE + unit8)
                                                 : (unit8 * HIDDEN_SIZE + hj8);
    wire [7:0] d_addr      = INPUT_MAJOR_WEIGHTS ? (elem8 * DENSE_SIZE  + unit8)
                                                 : (unit8 * HIDDEN_SIZE + elem8);

    // ------------------------------------------------------------------ parameter ROMs
    wire signed [15:0] w_f, w_i, w_g, w_o;       // W (input weights), one per gate
    wire signed [15:0] u_f, u_i, u_g, u_o;       // U (recurrent weights)
    wire signed [15:0] b_f, b_i, b_g, b_o;       // biases
    wire signed [15:0] d_w, d_b, alpha_w;        // shared dense
    wire signed [15:0] hw_t, hw_s, hw_h, hw_g;   // sensor head weights
    wire signed [15:0] hb;                       // sensor head bias

    weight_rom #(.ADDR_WIDTH(6), .DEPTH(64),  .MEM_FILE(F_W_FORGET))    r_w_f (.en(1'b1), .addr(w_addr_lstm[5:0]), .data_out(w_f));
    weight_rom #(.ADDR_WIDTH(6), .DEPTH(64),  .MEM_FILE(F_W_INPUT))     r_w_i (.en(1'b1), .addr(w_addr_lstm[5:0]), .data_out(w_i));
    weight_rom #(.ADDR_WIDTH(6), .DEPTH(64),  .MEM_FILE(F_W_CANDIDATE)) r_w_g (.en(1'b1), .addr(w_addr_lstm[5:0]), .data_out(w_g));
    weight_rom #(.ADDR_WIDTH(6), .DEPTH(64),  .MEM_FILE(F_W_OUTPUT))    r_w_o (.en(1'b1), .addr(w_addr_lstm[5:0]), .data_out(w_o));

    weight_rom #(.ADDR_WIDTH(8), .DEPTH(256), .MEM_FILE(F_U_FORGET))    r_u_f (.en(1'b1), .addr(u_addr_lstm), .data_out(u_f));
    weight_rom #(.ADDR_WIDTH(8), .DEPTH(256), .MEM_FILE(F_U_INPUT))     r_u_i (.en(1'b1), .addr(u_addr_lstm), .data_out(u_i));
    weight_rom #(.ADDR_WIDTH(8), .DEPTH(256), .MEM_FILE(F_U_CANDIDATE)) r_u_g (.en(1'b1), .addr(u_addr_lstm), .data_out(u_g));
    weight_rom #(.ADDR_WIDTH(8), .DEPTH(256), .MEM_FILE(F_U_OUTPUT))    r_u_o (.en(1'b1), .addr(u_addr_lstm), .data_out(u_o));

    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_B_FORGET))    r_b_f (.en(1'b1), .addr(unit_idx[3:0]), .data_out(b_f));
    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_B_INPUT))     r_b_i (.en(1'b1), .addr(unit_idx[3:0]), .data_out(b_i));
    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_B_CANDIDATE)) r_b_g (.en(1'b1), .addr(unit_idx[3:0]), .data_out(b_g));
    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_B_OUTPUT))    r_b_o (.en(1'b1), .addr(unit_idx[3:0]), .data_out(b_o));

    weight_rom #(.ADDR_WIDTH(8), .DEPTH(256), .MEM_FILE(F_W_SHARED))    r_dw  (.en(1'b1), .addr(d_addr),        .data_out(d_w));
    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_B_SHARED))    r_db  (.en(1'b1), .addr(unit_idx[3:0]), .data_out(d_b));
    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_ALPHA))       r_alp (.en(1'b1), .addr(unit_idx[3:0]), .data_out(alpha_w));

    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_W_TEMP))      r_hw_t (.en(1'b1), .addr(elem_idx[3:0]), .data_out(hw_t));
    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_W_SOLAR))     r_hw_s (.en(1'b1), .addr(elem_idx[3:0]), .data_out(hw_s));
    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_W_HUMIDITY))  r_hw_h (.en(1'b1), .addr(elem_idx[3:0]), .data_out(hw_h));
    weight_rom #(.ADDR_WIDTH(4), .DEPTH(16),  .MEM_FILE(F_W_GAS))       r_hw_g (.en(1'b1), .addr(elem_idx[3:0]), .data_out(hw_g));
    weight_rom #(.ADDR_WIDTH(2), .DEPTH(4),   .MEM_FILE(F_B_HEADS))     r_hb   (.en(1'b1), .addr(unit_idx[1:0]), .data_out(hb));

    // ------------------------------------------------------------------ operand muxes into the shared MAC
    reg signed [15:0] w_x_sel, w_u_sel, b_lstm_sel, head_w_sel;
    always @* begin
        case (gate_sel)
            2'd0:    begin w_x_sel = w_f; w_u_sel = u_f; b_lstm_sel = b_f; end
            2'd1:    begin w_x_sel = w_i; w_u_sel = u_i; b_lstm_sel = b_i; end
            2'd2:    begin w_x_sel = w_g; w_u_sel = u_g; b_lstm_sel = b_g; end
            default: begin w_x_sel = w_o; w_u_sel = u_o; b_lstm_sel = b_o; end
        endcase
        case (unit_idx[1:0])
            2'd0:    head_w_sel = hw_t;
            2'd1:    head_w_sel = hw_s;
            2'd2:    head_w_sel = hw_h;
            default: head_w_sel = hw_g;
        endcase
    end

    reg signed [15:0] mac_data, mac_weight, mac_bias;
    always @* begin
        case (phase)
            PHASE_DENSE: begin
                mac_data   = h_reg[elem_idx[3:0]];
                mac_weight = d_w;
                mac_bias   = d_b;
            end
            PHASE_HEAD: begin
                mac_data   = dense_reg[elem_idx[3:0]];
                mac_weight = head_w_sel;
                mac_bias   = hb;
            end
            default: begin                                   // LSTM gate: [x ; h] in one pass
                mac_data   = x_phase ? x_reg[elem_idx[1:0]] : h_reg[hj8[3:0]];
                mac_weight = x_phase ? w_x_sel : w_u_sel;
                mac_bias   = b_lstm_sel;
            end
        endcase
    end

    wire signed [39:0] mac_result;
    wire signed [15:0] mac_z = mac_result[15:0];

    mac_engine #(.DATA_WIDTH(16), .ACC_WIDTH(40), .FRACTIONAL_BITS(12)) u_mac (
        .clk(clk), .rst(rst),
        .start(mac_start), .valid(mac_valid), .last(mac_last),
        .data_in(mac_data), .weight_in(mac_weight), .bias_in(mac_bias),
        .result(mac_result), .done(mac_done)
    );

    // ------------------------------------------------------------------ activation (shared sigmoid/tanh LUT)
    wire               lut_en   = gate_capture_en | tanh_capture_en;
    wire signed [15:0] lut_in   = tanh_capture_en ? c_reg[unit_idx[3:0]] : mac_z;
    wire               lut_sig  = tanh_capture_en ? 1'b0 : (gate_sel != 2'd2);   // gate G is tanh
    wire signed [15:0] lut_out;

    activation_lut #(.SIGMOID_FILE(F_SIGMOID), .TANH_FILE(F_TANH)) u_lut (
        .data_in(lut_in), .activation_sel(lut_sig), .enable(lut_en), .data_out(lut_out)
    );

    // ------------------------------------------------------------------ cell / hidden update
    wire signed [15:0] gate_f = gate_reg[0];
    wire signed [15:0] gate_i = gate_reg[1];
    wire signed [15:0] gate_g = gate_reg[2];
    wire signed [15:0] gate_o = gate_reg[3];
    wire signed [15:0] c_cur  = c_reg[unit_idx[3:0]];
    wire signed [15:0] cell_next, hidden_next;

    elementwise_combine #(.DATA_WIDTH(16), .FRACTIONAL_BITS(12)) u_elem (
        .forget_gate(gate_f), .input_gate(gate_i), .candidate_gate(gate_g), .output_gate(gate_o),
        .cell_prev(c_cur), .tanh_cell_next(tanh_reg),
        .cell_next(cell_next), .hidden_next(hidden_next)
    );

    // ------------------------------------------------------------------ shared dense PReLU
    wire signed [15:0] prelu_out;
    prelu #(.DATA_WIDTH(16), .FRACTIONAL_BITS(12)) u_prelu (
        .data_in(mac_z), .alpha(alpha_w), .data_out(prelu_out)
    );

    wire [1:0]  sum_state;                 // rule-based summary outputs (combinational)
    wire [13:0] sum_flags;

    // ------------------------------------------------------------------ capture registers
    integer ii;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (ii = 0; ii < INPUT_SIZE;  ii = ii + 1) x_reg[ii]     <= 16'sd0;
            for (ii = 0; ii < HIDDEN_SIZE; ii = ii + 1) begin
                h_reg[ii] <= 16'sd0;
                h_new[ii] <= 16'sd0;
                c_reg[ii] <= 16'sd0;
            end
            for (ii = 0; ii < 4;           ii = ii + 1) gate_reg[ii]  <= 16'sd0;
            for (ii = 0; ii < DENSE_SIZE;  ii = ii + 1) dense_reg[ii] <= 16'sd0;
            tanh_reg        <= 16'sd0;
            pred_reg        <= 64'd0;
            summary_state_q <= 2'd0;
            summary_flags_q <= 14'd0;
        end else begin
            if (clear_state)
                for (ii = 0; ii < HIDDEN_SIZE; ii = ii + 1) begin
                    h_reg[ii] <= 16'sd0;
                    c_reg[ii] <= 16'sd0;
                end

            if (x_capture_en)     x_reg[x_capture_idx]            <= in_data_out;
            if (gate_capture_en)  gate_reg[gate_sel]              <= lut_out;
            if (cell_update_en)   c_reg[unit_idx[3:0]]            <= cell_next;
            if (tanh_capture_en)  tanh_reg                        <= lut_out;
            if (hidden_update_en) h_new[unit_idx[3:0]]            <= hidden_next;
            if (commit_h_en)
                for (ii = 0; ii < HIDDEN_SIZE; ii = ii + 1) h_reg[ii] <= h_new[ii];
            if (dense_capture_en) dense_reg[unit_idx[3:0]]        <= prelu_out;
            if (head_capture_en)  pred_reg[{unit_idx[1:0], 4'b0000} +: 16] <= mac_z;
            if (summary_en) begin
                summary_state_q <= sum_state;
                summary_flags_q <= sum_flags;
            end
        end
    end

    // ------------------------------------------------------------------ output buffer + rule-based summary
    output_buffer #(.DATA_WIDTH(16), .DEPTH(10), .ADDR_WIDTH(4)) u_output_buffer (
        .clk(clk), .rst(rst), .clear(run_clear),
        .write_en(output_store_en), .prediction_in(pred_reg),
        .read_en(out_rd_en), .read_addr(out_rd_addr), .prediction_out(out_rd_data),
        .sample_count(out_count)
    );

    // previous_sample = last sample of the window that produced this prediction (x_reg still holds it)
    rule_based_summary u_summary (
        .previous_sample({x_reg[3], x_reg[2], x_reg[1], x_reg[0]}),
        .prediction(pred_reg),
        .state(sum_state), .flags(sum_flags)
    );

    assign prediction = pred_reg;
    assign env_state  = summary_state_q;
    assign env_flags  = summary_flags_q;

endmodule
