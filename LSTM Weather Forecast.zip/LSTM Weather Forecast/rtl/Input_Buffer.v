`timescale 1ns/1ps
// =============================================================================
// Input_Buffer.v - 10 x 4 sample window (sample t, feature f at address t*4+f)
//   * synchronous read, 1-cycle latency (data_out valid the cycle after read_en)
//   * write port is used (a) by the host to load a window, (b) by the controller to
//     append a fed-back prediction ("loops back as next xt")
//   Fix: zero-initialised before $readmemh.
// =============================================================================
module input_buffer #(
    parameter DATA_WIDTH = 16,
    parameter ADDR_WIDTH = 6,
    parameter DEPTH      = 40,
    parameter MEM_FILE   = "golden_reference/mem/input_case_000.mem"
)(
    input  wire                          clk,
    input  wire                          rst,

    input  wire                          write_en,
    input  wire [ADDR_WIDTH-1:0]         write_addr,
    input  wire signed [DATA_WIDTH-1:0]  write_data,

    input  wire                          read_en,
    input  wire [ADDR_WIDTH-1:0]         read_addr,
    output reg signed [DATA_WIDTH-1:0]   data_out
);

    reg signed [DATA_WIDTH-1:0] memory [0:DEPTH-1];

    integer i;
    initial begin
        for (i = 0; i < DEPTH; i = i + 1)
            memory[i] = 0;
        $readmemh(MEM_FILE, memory);
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            data_out <= 0;
        end else begin
            if (write_en)
                memory[write_addr] <= write_data;

            if (read_en)
                data_out <= memory[read_addr];
        end
    end

endmodule
