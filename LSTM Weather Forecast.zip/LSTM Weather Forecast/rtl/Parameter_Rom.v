`timescale 1ns/1ps
// =============================================================================
// Parameter_Rom.v - asynchronous-read parameter ROM (weights, biases, alpha)
//   Fix: ROM is zero-initialised before $readmemh, so a short/missing file gives 0
//        instead of X propagating through the datapath.
// =============================================================================
module weight_rom #(
    parameter DATA_WIDTH = 16,
    parameter ADDR_WIDTH = 6,
    parameter DEPTH      = 64,
    parameter MEM_FILE   = "golden_reference/mem/w_forget.mem"
)(
    input  wire                         en,
    input  wire [ADDR_WIDTH-1:0]        addr,
    output wire signed [DATA_WIDTH-1:0] data_out
);

    reg signed [DATA_WIDTH-1:0] rom [0:DEPTH-1];

    integer i;
    initial begin
        for (i = 0; i < DEPTH; i = i + 1)
            rom[i] = 0;
        $readmemh(MEM_FILE, rom);
    end

    assign data_out = en ? rom[addr] : {DATA_WIDTH{1'b0}};

endmodule
