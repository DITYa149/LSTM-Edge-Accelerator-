// =============================================================================
// Element_wise.v - LSTM cell/hidden update for ONE neuron (UNCHANGED LOGIC)
//   cell_next   = sat( q(f*c_prev) + q(i*g) )
//   hidden_next = q(o * tanh_cell_next)
// =============================================================================
`timescale 1ns/1ps

module elementwise_combine #(
    parameter DATA_WIDTH      = 16,
    parameter FRACTIONAL_BITS = 12
)(
    input wire signed [DATA_WIDTH-1:0] forget_gate,
    input wire signed [DATA_WIDTH-1:0] input_gate,
    input wire signed [DATA_WIDTH-1:0] candidate_gate,
    input wire signed [DATA_WIDTH-1:0] output_gate,
    input wire signed [DATA_WIDTH-1:0] cell_prev,
    input wire signed [DATA_WIDTH-1:0] tanh_cell_next,

    output reg signed [DATA_WIDTH-1:0] cell_next,
    output reg signed [DATA_WIDTH-1:0] hidden_next
);

    reg signed [DATA_WIDTH:0] cell_sum;

    function signed [DATA_WIDTH-1:0] q_multiply;
        input signed [DATA_WIDTH-1:0] left;
        input signed [DATA_WIDTH-1:0] right;

        reg signed [(2*DATA_WIDTH)-1:0] product;
        reg signed [2*DATA_WIDTH:0] extended_product;
        reg        [2*DATA_WIDTH:0] magnitude;
        reg        [2*DATA_WIDTH:0] rounded_magnitude;
        reg signed [2*DATA_WIDTH:0] rounded_value;
        reg signed [2*DATA_WIDTH:0] positive_limit;
        reg signed [2*DATA_WIDTH:0] negative_limit;
        reg signed [2*DATA_WIDTH:0] half_lsb;

        begin
            product = $signed(left) * $signed(right);
            extended_product = {product[(2*DATA_WIDTH)-1], product};

            if (extended_product < 0)
                magnitude = -extended_product;
            else
                magnitude = extended_product;

            if (FRACTIONAL_BITS > 0) begin
                half_lsb = 1;
                half_lsb = half_lsb <<< (FRACTIONAL_BITS-1);
            end else begin
                half_lsb = 0;
            end

            rounded_magnitude =
                (magnitude + half_lsb) >> FRACTIONAL_BITS;

            if (extended_product < 0)
                rounded_value = -$signed(rounded_magnitude);
            else
                rounded_value = $signed(rounded_magnitude);

            positive_limit = (1 <<< (DATA_WIDTH-1)) - 1;
            negative_limit = -(1 <<< (DATA_WIDTH-1));

            if (rounded_value > positive_limit)
                q_multiply = {1'b0, {(DATA_WIDTH-1){1'b1}}};
            else if (rounded_value < negative_limit)
                q_multiply = {1'b1, {(DATA_WIDTH-1){1'b0}}};
            else
                q_multiply = rounded_value[DATA_WIDTH-1:0];
        end
    endfunction

    function signed [DATA_WIDTH-1:0] saturate_sum;
        input signed [DATA_WIDTH:0] value;
        reg signed [DATA_WIDTH:0] positive_limit;
        reg signed [DATA_WIDTH:0] negative_limit;
        begin
            positive_limit = (1 <<< (DATA_WIDTH-1)) - 1;
            negative_limit = -(1 <<< (DATA_WIDTH-1));

            if (value > positive_limit)
                saturate_sum = {1'b0, {(DATA_WIDTH-1){1'b1}}};
            else if (value < negative_limit)
                saturate_sum = {1'b1, {(DATA_WIDTH-1){1'b0}}};
            else
                saturate_sum = value[DATA_WIDTH-1:0];
        end
    endfunction

    always @* begin
        // c[t] = saturate(round(f*c[t-1]) + round(i*g))
        cell_sum =
            $signed(q_multiply(forget_gate, cell_prev)) +
            $signed(q_multiply(input_gate, candidate_gate));

        cell_next = saturate_sum(cell_sum);

        // h[t] = round(o * tanh(c[t]))
        hidden_next = q_multiply(output_gate, tanh_cell_next);
    end

endmodule
