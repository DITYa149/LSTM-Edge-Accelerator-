`timescale 1ns/1ps
// Three-class crisp condition summary. All values are signed Q4.12 codes.
// Feature packing at the interface is {gas, humidity, solar, temperature}.
`include "summary_thresholds.vh"
module rule_based_summary #(
    parameter integer THR_TREND  = `P_REDO_THR_TREND,
    parameter integer THR_HAZARD = `P_REDO_THR_HAZARD
)(
    input  wire [63:0] previous_sample,
    input  wire [63:0] prediction,
    output reg  [1:0]  state,             // 0 stable, 1 worsening, 2 hazardous
    output reg  [13:0] flags              // bit 0..2 trends, 3..6 hazards, 7 any hazard
);
    wire signed [15:0] p_temp = previous_sample[15:0];
    wire signed [15:0] p_solar = previous_sample[31:16];
    wire signed [15:0] p_humidity = previous_sample[47:32];
    wire signed [15:0] p_gas = previous_sample[63:48];
    wire signed [15:0] y_temp = prediction[15:0];
    wire signed [15:0] y_solar = prediction[31:16];
    wire signed [15:0] y_humidity = prediction[47:32];
    wire signed [15:0] y_gas = prediction[63:48];
    wire signed [16:0] temp_drop = $signed({p_temp[15], p_temp}) - $signed({y_temp[15], y_temp});
    wire signed [16:0] solar_drop = $signed({p_solar[15], p_solar}) - $signed({y_solar[15], y_solar});
    wire signed [16:0] gas_rise = $signed({y_gas[15], y_gas}) - $signed({p_gas[15], p_gas});
    wire signed [16:0] humidity_mag = y_humidity[15] ? -$signed({y_humidity[15], y_humidity}) : $signed({1'b0, y_humidity});
    wire sharp_cooling = temp_drop > THR_TREND;
    wire solar_dimming = solar_drop > THR_TREND;
    wire gas_buildup = gas_rise > THR_TREND;
    wire temp_hazard = y_temp < -THR_HAZARD;
    wire solar_hazard = y_solar < -THR_HAZARD;
    wire humidity_hazard = humidity_mag > THR_HAZARD;
    wire gas_hazard = y_gas > THR_HAZARD;
    wire any_hazard = temp_hazard | solar_hazard | humidity_hazard | gas_hazard;

    always @* begin
        flags = 14'd0;
        flags[0] = sharp_cooling;
        flags[1] = solar_dimming;
        flags[2] = gas_buildup;
        flags[3] = temp_hazard;
        flags[4] = solar_hazard;
        flags[5] = humidity_hazard;
        flags[6] = gas_hazard;
        flags[7] = any_hazard;
        if (any_hazard) state = 2'd2;
        else if (sharp_cooling | solar_dimming | gas_buildup) state = 2'd1;
        else state = 2'd0;
    end
endmodule
