`timescale 1ns/1ps
// =============================================================================
// Output_Buffer.v - shift-register history of the last DEPTH predictions
//   (each entry = {gas, humidity, solar, temp}, 4 x 16 bit).  Newest at DEPTH-1.
//   Added: synchronous `clear` so every run starts with an empty buffer and
//          sample_count equals the number of predictions produced by that run.
// =============================================================================
module output_buffer #(
    parameter DATA_WIDTH = 16,
    parameter DEPTH      = 10,
    parameter ADDR_WIDTH = 4
)(
    input  wire                  clk,
    input  wire                  rst,
    input  wire                  clear,

    input  wire                  write_en,
    input  wire [63:0]           prediction_in,

    input  wire                  read_en,
    input  wire [ADDR_WIDTH-1:0] read_addr,
    output reg  [63:0]           prediction_out,

    output reg  [3:0]            sample_count
);

    reg [63:0] memory [0:DEPTH-1];
    integer i;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            prediction_out <= 0;
            sample_count   <= 0;
            for (i = 0; i < DEPTH; i = i + 1)
                memory[i] <= 0;
        end else if (clear) begin
            prediction_out <= 0;
            sample_count   <= 0;
            for (i = 0; i < DEPTH; i = i + 1)
                memory[i] <= 0;
        end else begin
            if (read_en && read_addr < DEPTH)
                prediction_out <= memory[read_addr];

            if (write_en) begin
                for (i = 0; i < DEPTH-1; i = i + 1)
                    memory[i] <= memory[i+1];

                memory[DEPTH-1] <= prediction_in;

                if (sample_count < DEPTH)
                    sample_count <= sample_count + 1'b1;
            end
        end
    end

endmodule
