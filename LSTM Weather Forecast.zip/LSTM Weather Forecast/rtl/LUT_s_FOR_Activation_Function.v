`timescale 1ns/1ps
// =============================================================================
// LUT_s_FOR_Activation_Function.v - sigmoid / tanh lookup, 1025 points over [-8, +8]
//   entry i  =  f(-8 + i/64)  in Q3.12      (same index rule as before)
//   index    =  (clamp(code) + 32768 + 32) / 64     (nearest point, ties to higher index)
//
// Changes vs. the original:
//   * continuous assignment instead of `always @*`  ->  output is valid from time 0 even
//     when data_in never changes after reset (an `always @*` block does not run at t=0)
//   * LIMIT/STEP are localparams (constant-folded by synthesis, no runtime division)
//   * ROMs are zero-initialised before $readmemh
// =============================================================================
module activation_lut #(
    parameter DATA_WIDTH      = 16,
    parameter INPUT_WIDTH     = 16,
    parameter ADDR_WIDTH      = 11,
    parameter FRACTIONAL_BITS = 12,
    parameter SIGMOID_FILE    = "golden_reference/mem/sigmoid_lut.mem",
    parameter TANH_FILE       = "golden_reference/mem/tanh_lut.mem"
)(
    input  wire signed [INPUT_WIDTH-1:0] data_in,
    input  wire                          activation_sel,   // 1 = sigmoid, 0 = tanh
    input  wire                          enable,
    output wire signed [DATA_WIDTH-1:0]  data_out
);

    localparam LUT_DEPTH  = 1025;
    localparam integer LIMIT_CODE = 1 << (FRACTIONAL_BITS + 3);   // +8.0
    localparam integer STEP_CODE  = LIMIT_CODE / 512;             // 1/64
    localparam integer HALF_STEP  = STEP_CODE / 2;

    reg signed [DATA_WIDTH-1:0] sigmoid_rom [0:LUT_DEPTH-1];
    reg signed [DATA_WIDTH-1:0] tanh_rom    [0:LUT_DEPTH-1];

    integer k;
    initial begin
        for (k = 0; k < LUT_DEPTH; k = k + 1) begin
            sigmoid_rom[k] = 0;
            tanh_rom[k]    = 0;
        end
        $readmemh(SIGMOID_FILE, sigmoid_rom);
        $readmemh(TANH_FILE,    tanh_rom);
    end

    function [ADDR_WIDTH-1:0] lut_index;
        input signed [INPUT_WIDTH-1:0] d;
        integer code;
        integer idx;
        begin
            code = d;
            if (code < -LIMIT_CODE)     code = -LIMIT_CODE;
            else if (code > LIMIT_CODE) code =  LIMIT_CODE;
            idx = (code + LIMIT_CODE + HALF_STEP) / STEP_CODE;
            if (idx < 0)         idx = 0;
            else if (idx > 1024) idx = 1024;
            lut_index = idx;
        end
    endfunction

    wire [ADDR_WIDTH-1:0] lut_addr = lut_index(data_in);

    assign data_out = !enable        ? {DATA_WIDTH{1'b0}} :
                      activation_sel ? sigmoid_rom[lut_addr] :
                                       tanh_rom[lut_addr];

endmodule
