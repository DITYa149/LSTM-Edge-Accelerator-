`timescale 1ns/1ps
// =============================================================================
// FSM_Controller_TB.v - checks the sequencing contract of fsm_controller on its own
//
// A behavioural MAC stub answers mac_done (like the real MAC: the cycle after `last`,
// optionally delayed by EXTRA_LAT cycles to prove the FSM really waits for mac_done).
// The scoreboard samples every control output at the falling clock edge and checks:
//   * MAC passes: elem_idx counts 0,1,2,... without gaps; mac_start is a ONE-cycle pulse on
//     element 0 only; mac_last on the final element only (19 for LSTM, 15 for dense/head)
//   * counts: 64 LSTM passes per time step, 16 dense, 4 heads, per rollout step
//   * gate order F,I,G,O for each neuron, then CELL -> TANH -> HIDDEN in that order, unit_idx 0..15
//   * COMMIT once per time step (after 16 neurons), clear_state once per inference,
//     run_clear once per run
//   * input reads at ((rollout + t) mod 10)*4 + f, captured into x_reg slot f (one cycle later)
//   * rollout window writes at (k mod 10)*4 + f for the k-th feedback, f = 0..3
//   * dense units 0..15, head units 0..3, OUTPUT_STORE / SUMMARY / pred_valid once per rollout
//   * done is one cycle, busy is low afterwards; start pulses during the run are ignored
// Compile-time: -DROLLOUT=3  -DEXTRA_LAT=0
// =============================================================================
`ifndef ROLLOUT
  `define ROLLOUT 3
`endif
`ifndef EXTRA_LAT
  `define EXTRA_LAT 0
`endif

module FSM_Controller_TB;

    localparam R = `ROLLOUT;
    localparam T = 10;
    localparam LAT = `EXTRA_LAT;

    reg clk = 0, rst = 1, start = 0;
    always #5 clk = ~clk;

    wire busy, done, pred_valid;
    wire [3:0] time_step;
    wire [7:0] rollout_idx;
    wire input_read_en, x_capture_en, window_write_en;
    wire [5:0] input_read_addr, window_write_addr;
    wire [1:0] x_capture_idx, window_write_idx;
    wire mac_start, mac_valid, mac_last;
    wire [1:0] phase, gate_sel;
    wire [5:0] unit_idx, elem_idx;
    wire clear_state, run_clear, gate_capture_en, cell_update_en, tanh_capture_en, hidden_update_en;
    wire commit_h_en, dense_capture_en, head_capture_en, output_store_en, summary_en;

    // ---------------- MAC stub: done = (valid & last) delayed by 1 + LAT cycles
    reg [LAT+1:0] done_pipe = 0;
    always @(posedge clk) done_pipe <= {done_pipe[LAT:0], (mac_valid & mac_last)};
    wire mac_done = done_pipe[LAT+1];

    fsm_controller #(.TIME_STEPS(T), .INPUT_SIZE(4), .HIDDEN_SIZE(16), .DENSE_SIZE(16),
                     .HEAD_COUNT(4), .ROLLOUT_STEPS(R)) dut (
        .clk(clk), .rst(rst), .start(start), .mac_done(mac_done),
        .busy(busy), .done(done), .pred_valid(pred_valid), .time_step(time_step), .rollout_idx(rollout_idx),
        .input_read_en(input_read_en), .input_read_addr(input_read_addr),
        .x_capture_en(x_capture_en), .x_capture_idx(x_capture_idx),
        .window_write_en(window_write_en), .window_write_addr(window_write_addr), .window_write_idx(window_write_idx),
        .mac_start(mac_start), .mac_valid(mac_valid), .mac_last(mac_last),
        .phase(phase), .gate_sel(gate_sel), .unit_idx(unit_idx), .elem_idx(elem_idx),
        .clear_state(clear_state), .run_clear(run_clear), .gate_capture_en(gate_capture_en),
        .cell_update_en(cell_update_en), .tanh_capture_en(tanh_capture_en), .hidden_update_en(hidden_update_en),
        .commit_h_en(commit_h_en), .dense_capture_en(dense_capture_en), .head_capture_en(head_capture_en),
        .output_store_en(output_store_en), .summary_en(summary_en));

    // ---------------- scoreboard
    integer errors = 0;
    task err(input [255:0] msg);
        begin
            errors = errors + 1;
            if (errors < 15) $display("  [FAIL @%0t] %0s  (state: phase=%0d gate=%0d unit=%0d elem=%0d)", $time, msg, phase, gate_sel, unit_idx, elem_idx);
        end
    endtask

    reg run = 0;
    integer exp_elem = 0;
    integer lstm_passes = 0, dense_passes = 0, head_passes = 0;
    integer exp_gate = 0, exp_unit = 0, seq = 0;       // seq: 0 gates, 1 expect cell, 2 expect tanh, 3 expect hidden
    integer hidden_in_step = 0, commits = 0, clears = 0, run_clears = 0;
    integer rd_t = 0, rd_r = 0, rd_f = 0, reads = 0, caps = 0, cap_f = 0;
    integer wr_k = 0, wr_f = 0, writes = 0;
    integer d_unit = 0, dense_caps = 0, h_unit = 0, head_caps = 0;
    integer stores = 0, sums = 0, preds = 0, dones = 0;
    integer exp_addr, last_elem;
    reg done_d = 0, rd_d = 0, mac_start_d = 0;
    reg [1:0] rd_f_d1 = 0;
    reg x_cap_expected = 0;
    integer cycles = 0;
    integer cap_check_f;

    always @(negedge clk) begin
        if (run) begin
            cycles = cycles + 1;

            // ---- MAC element sequencing
            last_elem = (phase == 2'd0) ? 19 : 15;
            if (mac_valid) begin
                if (elem_idx !== exp_elem) err("elem_idx not contiguous");
                if (mac_start !== (exp_elem == 0)) err("mac_start must be a pulse on element 0 only");
                if (mac_last !== (exp_elem == last_elem)) err("mac_last on wrong element");
                if (exp_elem == last_elem) begin
                    exp_elem = 0;
                    if (phase == 2'd0) lstm_passes = lstm_passes + 1;
                    else if (phase == 2'd1) dense_passes = dense_passes + 1;
                    else if (phase == 2'd2) head_passes = head_passes + 1;
                end else exp_elem = exp_elem + 1;
            end else begin
                if (mac_start || mac_last) err("mac_start/last without valid");
                if (exp_elem != 0) err("mac_valid dropped in the middle of a pass");
            end

            // ---- LSTM neuron sequence
            if (gate_capture_en) begin
                if (seq != 0) err("gate capture out of order");
                if (phase !== 2'd0) err("gate capture outside LSTM phase");
                if (gate_sel !== exp_gate) err("gate order must be F,I,G,O");
                if (unit_idx !== exp_unit) err("neuron index wrong at gate capture");
                if (exp_gate == 3) begin exp_gate = 0; seq = 1; end else exp_gate = exp_gate + 1;
            end
            if (cell_update_en)   begin if (seq != 1 || unit_idx !== exp_unit) err("CELL out of order"); seq = 2; end
            if (tanh_capture_en)  begin if (seq != 2 || unit_idx !== exp_unit) err("TANH out of order"); seq = 3; end
            if (hidden_update_en) begin
                if (seq != 3 || unit_idx !== exp_unit) err("HIDDEN out of order");
                seq = 0; hidden_in_step = hidden_in_step + 1;
                exp_unit = (exp_unit == 15) ? 0 : exp_unit + 1;
            end
            if (commit_h_en) begin
                if (hidden_in_step != 16) err("COMMIT before all 16 neurons were done");
                if (seq != 0) err("COMMIT in the middle of a neuron");
                hidden_in_step = 0; commits = commits + 1;
            end
            if (clear_state) clears = clears + 1;
            if (run_clear)   run_clears = run_clears + 1;

            // ---- input window reads / captures (capture one cycle after the read)
            if (input_read_en) begin
                exp_addr = ((rd_r + rd_t) % 10) * 4 + rd_f;
                if (input_read_addr !== exp_addr) begin
                    err("input_read_addr wrong");
                    if (errors < 15) $display("        got %0d expected %0d (rollout %0d, t %0d, f %0d)", input_read_addr, exp_addr, rd_r, rd_t, rd_f);
                end
                reads = reads + 1;
                if (rd_f == 3) begin
                    rd_f = 0;
                    if (rd_t == T - 1) begin rd_t = 0; rd_r = rd_r + 1; end else rd_t = rd_t + 1;
                end else rd_f = rd_f + 1;
            end
            if (x_capture_en) begin
                if (x_capture_idx !== cap_f[1:0]) err("x_capture_idx not sequential");
                cap_f = (cap_f == 3) ? 0 : cap_f + 1;
                caps = caps + 1;
            end

            // ---- window feedback writes
            if (window_write_en) begin
                exp_addr = (wr_k % 10) * 4 + wr_f;
                if (window_write_addr !== exp_addr) err("window_write_addr wrong");
                if (window_write_idx !== wr_f[1:0]) err("window_write_idx wrong");
                writes = writes + 1;
                if (wr_f == 3) begin wr_f = 0; wr_k = wr_k + 1; end else wr_f = wr_f + 1;
            end

            // ---- dense / head captures
            if (dense_capture_en) begin
                if (phase !== 2'd1 || unit_idx !== d_unit) err("dense capture unit wrong");
                d_unit = (d_unit == 15) ? 0 : d_unit + 1; dense_caps = dense_caps + 1;
            end
            if (head_capture_en) begin
                if (phase !== 2'd2 || unit_idx !== h_unit) err("head capture unit wrong");
                h_unit = (h_unit == 3) ? 0 : h_unit + 1; head_caps = head_caps + 1;
            end
            if (output_store_en) stores = stores + 1;
            if (summary_en)      sums = sums + 1;
            if (pred_valid)      preds = preds + 1;

            // ---- done / busy
            if (done) begin
                dones = dones + 1;
                if (done_d) err("done longer than one cycle");
            end
            if (busy && done) err("busy and done together");
            done_d = done;
        end
    end

    // exactly one rollout step must be finished between consecutive pred_valid strobes
    // (checked at the end through the totals)

    integer timeout;
    integer start_cycle;
    initial begin
        repeat (4) @(negedge clk);
        rst = 0;
        repeat (3) @(negedge clk);

        $display("FSM test: ROLLOUT=%0d, extra MAC latency=%0d", R, LAT);
        run = 1;
        @(negedge clk); start = 1;
        @(negedge clk); start = 0;
        start_cycle = cycles;

        timeout = 0;
        while (!done && timeout < 2000000) begin
            @(negedge clk);
            timeout = timeout + 1;
            // poke start during the run: must be ignored
            if (timeout == 777 || timeout == 20011 || timeout == 31111) begin start = 1; @(negedge clk); start = 0; end
        end
        repeat (5) @(negedge clk);
        run = 0;

        if (!(timeout < 2000000)) err("TIMEOUT");
        if (busy) err("busy still high after done");
        if (lstm_passes  != R * T * 64) begin errors = errors + 1; $display("  [FAIL] LSTM passes %0d expected %0d", lstm_passes,  R * T * 64); end
        if (dense_passes != R * 16)     begin errors = errors + 1; $display("  [FAIL] dense passes %0d expected %0d", dense_passes, R * 16); end
        if (head_passes  != R * 4)      begin errors = errors + 1; $display("  [FAIL] head passes %0d expected %0d",  head_passes,  R * 4); end
        if (hidden_in_step != 0)        begin errors = errors + 1; $display("  [FAIL] unfinished time step"); end
        if (commits != R * T)           begin errors = errors + 1; $display("  [FAIL] commits %0d expected %0d", commits, R * T); end
        if (clears != R)                begin errors = errors + 1; $display("  [FAIL] clear_state %0d expected %0d", clears, R); end
        if (run_clears != 1)            begin errors = errors + 1; $display("  [FAIL] run_clear %0d expected 1", run_clears); end
        if (reads != R * T * 4)         begin errors = errors + 1; $display("  [FAIL] input reads %0d expected %0d", reads, R * T * 4); end
        if (caps != R * T * 4)          begin errors = errors + 1; $display("  [FAIL] x captures %0d expected %0d", caps, R * T * 4); end
        if (writes != (R - 1) * 4)      begin errors = errors + 1; $display("  [FAIL] window writes %0d expected %0d", writes, (R - 1) * 4); end
        if (dense_caps != R * 16)       begin errors = errors + 1; $display("  [FAIL] dense captures %0d", dense_caps); end
        if (head_caps != R * 4)         begin errors = errors + 1; $display("  [FAIL] head captures %0d", head_caps); end
        if (stores != R || sums != R || preds != R) begin errors = errors + 1; $display("  [FAIL] store/summary/pred_valid = %0d/%0d/%0d expected %0d", stores, sums, preds, R); end
        if (dones != 1)                 begin errors = errors + 1; $display("  [FAIL] done pulses %0d expected 1 (start during run must be ignored)", dones); end

        $display("  passes: LSTM %0d, dense %0d, head %0d | commits %0d | feedback writes %0d | cycles %0d",
                 lstm_passes, dense_passes, head_passes, commits, writes, cycles);
        if (errors == 0) $display("ALL FSM TESTS PASSED (ROLLOUT=%0d, extra latency=%0d)", R, LAT);
        else             $display("FSM TESTS FAILED: %0d", errors);
        $finish;
    end

    initial begin
        #4000000000;
        $display("FSM TESTS FAILED: global watchdog");
        $finish;
    end
endmodule
