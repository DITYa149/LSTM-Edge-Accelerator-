`timescale 1ns/1ps
// =============================================================================
// Data_Flow_TB.v - END-TO-END self-checking testbench
//
// For every case NNN it
//   1. loads golden_reference/<set>/input_case_NNN.mem into the window through the host port
//   2. pulses start (no reset between cases -> proves state / buffers are re-initialised)
//   3. checks, bit-exactly against the Python model (golden_model.py):
//        - every prediction     (expected_pred_case_NNN.mem)
//        - every rule summary   (expected_summary_case_NNN.mem  = {state[1:0], flags[13:0]})
//        - h(t) after every time step of every inference (expected_h_case_NNN.mem)
//        - the output-buffer contents / sample_count after the run
//        - protocol: busy during the run, 1-cycle done, pred_valid count, cycle count
//
// Compile-time options (iverilog -D...):
//   MEM_DIR      "golden_reference/synthetic/"   directory with the .mem files (trailing /)
//   NUM_CASES    number of cases to run          (default 3)
//   ROLLOUT      ROLLOUT_STEPS of the DUT, 1..10 (default 10)
//   INPUT_MAJOR  0/1  INPUT_MAJOR_WEIGHTS of the DUT
// =============================================================================
`ifndef MEM_DIR
  `define MEM_DIR "mem/"
`endif
`ifndef NUM_CASES
  `define NUM_CASES 1
`endif
`ifndef ROLLOUT
  `define ROLLOUT 1
`endif
`ifndef INPUT_MAJOR
  `define INPUT_MAJOR 0
`endif

module Data_Flow_TB;

    localparam MEM_DIR = `MEM_DIR;
    localparam R       = `ROLLOUT;
    localparam NCASES  = `NUM_CASES;
    localparam TS      = 10;

    reg         clk = 0;
    reg         rst = 1;
    reg         start = 0;
    reg         in_load_en = 0;
    reg  [5:0]  in_load_addr = 0;
    reg  signed [15:0] in_load_data = 0;
    reg         out_rd_en = 0;
    reg  [3:0]  out_rd_addr = 0;

    wire        busy, done, pred_valid;
    wire [63:0] prediction, out_rd_data;
    wire [1:0]  env_state;
    wire [13:0] env_flags;
    wire [3:0]  out_count;

    data_flow #(
        .ROLLOUT_STEPS(R),
        .INPUT_MAJOR_WEIGHTS(`INPUT_MAJOR),
        .MEM_DIR(MEM_DIR)
    ) dut (
        .clk(clk), .rst(rst), .start(start), .busy(busy), .done(done),
        .in_load_en(in_load_en), .in_load_addr(in_load_addr), .in_load_data(in_load_data),
        .pred_valid(pred_valid), .prediction(prediction),
        .env_state(env_state), .env_flags(env_flags),
        .out_rd_en(out_rd_en), .out_rd_addr(out_rd_addr), .out_rd_data(out_rd_data),
        .out_count(out_count)
    );

    always #5 clk = ~clk;

    // ------------------------------------------------------------------ expected data
    reg signed [15:0] in_mem   [0:39];
    reg        [63:0] exp_pred [0:9];
    reg        [15:0] exp_sum  [0:9];
    reg signed [15:0] exp_h    [0:1599];
    reg signed [15:0] exp_c    [0:1599];
    reg [8*200-1:0]   fname;
    reg [7:0]         d2, d1, d0;

    integer errors, case_errors, total_errors;
    integer c, i, j;
    integer pred_cnt, commit_cnt, h_cnt, done_cnt;
    integer cycle_cnt, start_cycle, first_pred_cycle, end_cycle;
    reg     commit_pending;
    integer st0, st1, st2, st3;
    reg     run_active;

    task set_digits(input integer n);
        begin
            d2 = "0" + (n / 100);
            d1 = "0" + ((n / 10) % 10);
            d0 = "0" + (n % 10);
        end
    endtask

    task load_expected(input integer n);
        begin
            set_digits(n);
            fname = {MEM_DIR, "input_case_", d2, d1, d0, ".mem"};            $readmemh(fname, in_mem);
            fname = {MEM_DIR, "expected_pred_case_", d2, d1, d0, ".mem"};    $readmemh(fname, exp_pred);
            fname = {MEM_DIR, "expected_summary_case_", d2, d1, d0, ".mem"}; $readmemh(fname, exp_sum);
            fname = {MEM_DIR, "expected_h_case_", d2, d1, d0, ".mem"};       $readmemh(fname, exp_h);
            fname = {MEM_DIR, "expected_c_case_", d2, d1, d0, ".mem"};       $readmemh(fname, exp_c);
        end
    endtask

    task load_window;
        integer k;
        begin
            for (k = 0; k < 40; k = k + 1) begin
                @(negedge clk);
                in_load_en   = 1'b1;
                in_load_addr = k;
                in_load_data = in_mem[k];
            end
            @(negedge clk);
            in_load_en = 1'b0;
        end
    endtask


    // ------------------------------------------------------------------ monitors (sample at negedge = mid-cycle)
    always @(posedge clk) cycle_cnt <= cycle_cnt + 1;

    // predictions + summaries
    always @(negedge clk) begin
        if (run_active && pred_valid) begin
            if (pred_cnt < R) begin
                if (prediction !== exp_pred[pred_cnt]) begin
                    if (case_errors < 12)
                        $display("  [FAIL] case %0d pred %0d: got %h expected %h", c, pred_cnt, prediction, exp_pred[pred_cnt]);
                    errors = errors + 1; case_errors = case_errors + 1;
                end
                if ({env_state, env_flags} !== exp_sum[pred_cnt]) begin
                    if (case_errors < 12)
                        $display("  [FAIL] case %0d summary %0d: got %h expected %h", c, pred_cnt, {env_state, env_flags}, exp_sum[pred_cnt]);
                    errors = errors + 1; case_errors = case_errors + 1;
                end
            end
            if (pred_cnt == 0) first_pred_cycle = cycle_cnt;
            case (env_state)
                2'd0: st0 = st0 + 1;
                2'd1: st1 = st1 + 1;
                2'd2: st2 = st2 + 1;
                default: st3 = st3 + 1;
            endcase
            pred_cnt = pred_cnt + 1;
        end
    end

    // hidden state after every commit
    always @(negedge clk) begin
        if (run_active) begin
            if (commit_pending) begin
                for (j = 0; j < 16; j = j + 1) begin
                    if (h_cnt < R * TS && dut.h_reg[j] !== exp_h[h_cnt * 16 + j]) begin
                        if (case_errors < 12)
                            $display("  [FAIL] case %0d h(t) #%0d neuron %0d: got %h expected %h",
                                     c, h_cnt, j, dut.h_reg[j], exp_h[h_cnt * 16 + j]);
                        errors = errors + 1; case_errors = case_errors + 1;
                    end
                    if (h_cnt < R * TS && dut.c_reg[j] !== exp_c[h_cnt * 16 + j]) begin
                        if (case_errors < 12)
                            $display("  [FAIL] case %0d c(t) #%0d neuron %0d: got %h expected %h",
                                     c, h_cnt, j, dut.c_reg[j], exp_c[h_cnt * 16 + j]);
                        errors = errors + 1; case_errors = case_errors + 1;
                    end
                end
                h_cnt = h_cnt + 1;
                commit_pending = 1'b0;
            end
            if (dut.commit_h_en) begin
                commit_pending = 1'b1;
                commit_cnt = commit_cnt + 1;
            end
        end
    end

    // protocol: busy must stay high during a run until done; done is a single-cycle pulse
    reg done_d;
    always @(negedge clk) begin
        done_d <= done;
        if (run_active && done) done_cnt = done_cnt + 1;
        if (run_active && done && done_d) begin
            $display("  [FAIL] done is longer than one cycle");
            errors = errors + 1; case_errors = case_errors + 1;
        end
    end

    // ------------------------------------------------------------------ one case
    task run_case(input integer n);
        integer timeout;
        integer exp_idx;
        reg [63:0] want;
        begin
            case_errors    = 0;
            pred_cnt       = 0;
            commit_cnt     = 0;
            h_cnt          = 0;
            done_cnt       = 0;
            commit_pending = 1'b0;
            first_pred_cycle = 0;
            st0 = 0; st1 = 0; st2 = 0; st3 = 0;

            load_expected(n);
            load_window;

            @(negedge clk);
            run_active  = 1'b1;
            start_cycle = cycle_cnt;
            start       = 1'b1;
            @(negedge clk);
            start       = 1'b0;

            timeout = 0;
            while (!done && timeout < 400000) begin
                @(negedge clk);
                timeout = timeout + 1;
                if (timeout == 3 && !busy) begin
                    $display("  [FAIL] busy not asserted after start");
                    errors = errors + 1; case_errors = case_errors + 1;
                end
            end
            end_cycle = cycle_cnt;
            if (!done) begin
                $display("  [FAIL] case %0d: TIMEOUT waiting for done", n);
                errors = errors + 1; case_errors = case_errors + 1;
            end

            @(negedge clk);
            @(negedge clk);
            run_active = 1'b0;

            if (pred_cnt !== R) begin
                $display("  [FAIL] case %0d: %0d pred_valid strobes, expected %0d", n, pred_cnt, R);
                errors = errors + 1; case_errors = case_errors + 1;
            end
            if (commit_cnt !== R * TS) begin
                $display("  [FAIL] case %0d: %0d hidden-state commits, expected %0d", n, commit_cnt, R * TS);
                errors = errors + 1; case_errors = case_errors + 1;
            end
            if (done_cnt !== 1) begin
                $display("  [FAIL] case %0d: done seen %0d times, expected 1", n, done_cnt);
                errors = errors + 1; case_errors = case_errors + 1;
            end
            if (busy) begin
                $display("  [FAIL] busy still high after done");
                errors = errors + 1; case_errors = case_errors + 1;
            end
            if (out_count !== R) begin
                $display("  [FAIL] case %0d: out_count = %0d, expected %0d", n, out_count, R);
                errors = errors + 1; case_errors = case_errors + 1;
            end

            // output buffer: entries [10-R .. 9] = predictions 0..R-1 (oldest..newest), the rest cleared
            for (i = 0; i < 10; i = i + 1) begin
                @(negedge clk); out_rd_en = 1'b1; out_rd_addr = i;
                @(negedge clk); out_rd_en = 1'b0;
                exp_idx = i - (10 - R);
                want = (exp_idx >= 0) ? exp_pred[exp_idx] : 64'd0;
                if (out_rd_data !== want) begin
                    if (case_errors < 12)
                        $display("  [FAIL] case %0d output buffer[%0d]: got %h expected %h", n, i, out_rd_data, want);
                    errors = errors + 1; case_errors = case_errors + 1;
                end
            end

            $display("case %0d: %s  (%0d cycles/inference, %0d total, %0d predictions, %0d h/c(t) checks, env states stable/worsening/hazardous/reserved = %0d/%0d/%0d/%0d)",
                     n, case_errors == 0 ? "PASS" : "FAIL",
                     first_pred_cycle - start_cycle, end_cycle - start_cycle, pred_cnt, h_cnt, st0, st1, st2, st3);
            total_errors = total_errors + case_errors;
        end
    endtask

    // ------------------------------------------------------------------ main
    initial begin
        errors = 0; total_errors = 0; case_errors = 0;
        cycle_cnt = 0; run_active = 1'b0; commit_pending = 1'b0; done_d = 1'b0;
        pred_cnt = 0; commit_cnt = 0; h_cnt = 0; done_cnt = 0;
        st0 = 0; st1 = 0; st2 = 0; st3 = 0;
        c = 0;

        $display("==============================================================");
        $display("Data_Flow end-to-end test   MEM_DIR=%0s  ROLLOUT=%0d  INPUT_MAJOR=%0d  cases=%0d",
                 MEM_DIR, R, `INPUT_MAJOR, NCASES);
        $display("==============================================================");

        repeat (4) @(negedge clk);
        rst = 1'b0;
        repeat (2) @(negedge clk);

        for (c = 0; c < NCASES; c = c + 1)
            run_case(c);

        $display("==============================================================");
        if (total_errors == 0)
            $display("RESULT : PASS  (%0d cases, RTL == Python model, bit exact)", NCASES);
        else
            $display("RESULT : FAIL  (%0d mismatches)", total_errors);
        $display("==============================================================");
        $finish;
    end

    // global watchdog
    initial begin
        #2000000000;
        $display("RESULT : FAIL  (global watchdog)");
        $finish;
    end

endmodule
