`timescale 1ns/1ps

// ============================================================
// Element-Wise Combine Testbench
//
// DUT:
//     elementwise_combine
//
// Purpose:
//     1. Verify c_t calculation
//     2. Verify h_t calculation
//     3. Compare RTL results with independently prepared
//        Q4.12 expected values
//
// LSTM equations:
//     c_t = saturate( round(f_t * c_(t-1))
//                   + round(i_t * g_t) )
//
//     h_t = round(o_t * tanh(c_t))
//
// NOTE:
//     tanh_cell_next is supplied to this unit test as the
//     already-computed tanh(c_t) value. The LUT is tested
//     separately in LUT_TB.v.
// ============================================================

module ElementWise_TB;

    parameter DATA_WIDTH      = 16;
    parameter FRACTIONAL_BITS = 12;

    // --------------------------------------------------------
    // DUT inputs
    // --------------------------------------------------------
    reg signed [DATA_WIDTH-1:0] forget_gate;
    reg signed [DATA_WIDTH-1:0] input_gate;
    reg signed [DATA_WIDTH-1:0] candidate_gate;
    reg signed [DATA_WIDTH-1:0] output_gate;
    reg signed [DATA_WIDTH-1:0] cell_prev;
    reg signed [DATA_WIDTH-1:0] tanh_cell_next;

    // --------------------------------------------------------
    // DUT outputs
    // --------------------------------------------------------
    wire signed [DATA_WIDTH-1:0] cell_next;
    wire signed [DATA_WIDTH-1:0] hidden_next;

    // --------------------------------------------------------
    // Expected values
    // --------------------------------------------------------
    reg signed [DATA_WIDTH-1:0] expected_cell;
    reg signed [DATA_WIDTH-1:0] expected_hidden;

    // --------------------------------------------------------
    // Counters
    // --------------------------------------------------------
    integer test_count;
    integer pass_count;
    integer fail_count;
    integer cell_error;
    integer hidden_error;

    // --------------------------------------------------------
    // DUT instantiation
    // --------------------------------------------------------
    elementwise_combine #(
        .DATA_WIDTH(DATA_WIDTH),
        .FRACTIONAL_BITS(FRACTIONAL_BITS)
    ) DUT (
        .forget_gate(forget_gate),
        .input_gate(input_gate),
        .candidate_gate(candidate_gate),
        .output_gate(output_gate),
        .cell_prev(cell_prev),
        .tanh_cell_next(tanh_cell_next),
        .cell_next(cell_next),
        .hidden_next(hidden_next)
    );

    // --------------------------------------------------------
    // Q4.12 display helper
    // Converts signed fixed-point integer to decimal.
    // --------------------------------------------------------
    task display_q412;
        input signed [DATA_WIDTH-1:0] value;
        begin
            $write("%0d.%03d",
                   value >>> FRACTIONAL_BITS,
                   ((value < 0) ? -value : value) % (1 << FRACTIONAL_BITS));
        end
    endtask

    // --------------------------------------------------------
    // Run one complete test vector
    // --------------------------------------------------------
    task run_test;
        input [7:0] test_number;

        begin
            #1;

            // Absolute error in fixed-point LSBs
            cell_error = cell_next - expected_cell;
            if (cell_error < 0)
                cell_error = -cell_error;

            hidden_error = hidden_next - expected_hidden;
            if (hidden_error < 0)
                hidden_error = -hidden_error;

            test_count = test_count + 1;

            $display("");
            $display("------------------------------------------------------------");
            $display("TEST %0d", test_number);
            $display("------------------------------------------------------------");

            $display("Inputs:");
            $display("  forget_gate    = %h", forget_gate);
            $display("  input_gate     = %h", input_gate);
            $display("  candidate_gate = %h", candidate_gate);
            $display("  output_gate    = %h", output_gate);
            $display("  cell_prev      = %h", cell_prev);
            $display("  tanh_cell_next = %h", tanh_cell_next);

            $display("");
            $display("CELL STATE c_t:");
            $display("  Expected       = %h", expected_cell);
            $display("  RTL            = %h", cell_next);
            $display("  Error          = %0d LSB", cell_error);

            $write("  Expected Q4.12 = ");
            display_q412(expected_cell);
            $display("");

            $write("  RTL Q4.12      = ");
            display_q412(cell_next);
            $display("");

            if (cell_next === expected_cell) begin
                $display("  c_t STATUS     = PASS");
                pass_count = pass_count + 1;
            end
            else begin
                $display("  c_t STATUS     = FAIL");
                fail_count = fail_count + 1;
            end

            $display("");
            $display("HIDDEN STATE h_t:");
            $display("  Expected       = %h", expected_hidden);
            $display("  RTL            = %h", hidden_next);
            $display("  Error          = %0d LSB", hidden_error);

            $write("  Expected Q4.12 = ");
            display_q412(expected_hidden);
            $display("");

            $write("  RTL Q4.12      = ");
            display_q412(hidden_next);
            $display("");

            if (hidden_next === expected_hidden) begin
                $display("  h_t STATUS     = PASS");
                pass_count = pass_count + 1;
            end
            else begin
                $display("  h_t STATUS     = FAIL");
                fail_count = fail_count + 1;
            end
        end
    endtask

    // --------------------------------------------------------
    // Test sequence
    // --------------------------------------------------------
    initial begin

        test_count = 0;
        pass_count = 0;
        fail_count = 0;

        // ----------------------------------------------------
        // TEST 1
        //
        // f = 0.5
        // i = 0.25
        // g = 0.5
        // o = 0.5
        // c_prev = 0.5
        // tanh(c_t) = 0.358398... -> 16'h05BC
        //
        // Expected:
        // c_t = 0.375       -> 16'h0600
        // h_t = 0.179199... -> 16'h02DE
        // ----------------------------------------------------
        forget_gate    = 16'sh0800;
        input_gate     = 16'sh0400;
        candidate_gate = 16'sh0800;
        output_gate    = 16'sh0800;
        cell_prev      = 16'sh0800;
        tanh_cell_next = 16'sh05BC;

        expected_cell   = 16'sh0600;
        expected_hidden = 16'sh02DE;

        run_test(1);

        // ----------------------------------------------------
        // TEST 2
        //
        // f = 0.75
        // i = 0.5
        // g = 0.25
        // o = 0.625
        // c_prev = -0.25
        // tanh(c_t) = -0.0625 -> 16'hFF00
        //
        // Expected:
        // c_t = -0.0625 -> 16'hFF00
        // h_t = -0.0390625 -> 16'hFF60
        // ----------------------------------------------------
        forget_gate    = 16'sh0C00;
        input_gate     = 16'sh0800;
        candidate_gate = 16'sh0400;
        output_gate    = 16'sh0A00;
        cell_prev      = 16'shFC00;
        tanh_cell_next = 16'shFF00;

        expected_cell   = 16'shFF00;
        expected_hidden = 16'shFF60;

        run_test(2);

        // ----------------------------------------------------
        // TEST 3
        //
        // Negative gates/candidate.
        //
        // Expected:
        // c_t = -0.625  -> 16'hF600
        // h_t = -0.277344 -> 16'hFB90
        // ----------------------------------------------------
        forget_gate    = 16'shF800;
        input_gate     = 16'sh0C00;
        candidate_gate = 16'shF800;
        output_gate    = 16'sh0800;
        cell_prev      = 16'sh0800;
        tanh_cell_next = 16'shF720;

        expected_cell   = 16'shF600;
        expected_hidden = 16'shFB90;

        run_test(3);

        // ----------------------------------------------------
        // TEST 4
        //
        // Non-power-of-two fixed-point values.
        //
        // Expected:
        // c_t = -0.370361 -> 16'hFA15
        // h_t = -0.088379 -> 16'hFE96
        // ----------------------------------------------------
        forget_gate    = 16'sh0E66;
        input_gate     = 16'sh019A;
        candidate_gate = 16'sh0CCD;
        output_gate    = 16'sh0400;
        cell_prev      = 16'shF800;
        tanh_cell_next = 16'shFA57;

        expected_cell   = 16'shFA15;
        expected_hidden = 16'shFE96;

        run_test(4);

        // ----------------------------------------------------
        // FINAL SUMMARY
        // ----------------------------------------------------
        $display("");
        $display("============================================================");
        $display("          ELEMENT-WISE COMBINE TEST SUMMARY");
        $display("============================================================");
        $display("Test vectors        : %0d", test_count);
        $display("Individual PASS     : %0d", pass_count);
        $display("Individual FAIL     : %0d", fail_count);
        $display("");

        if (fail_count == 0)
            $display("OVERALL RESULT      : PASS");
        else
            $display("OVERALL RESULT      : FAIL");

        $display("============================================================");

        $finish;
    end

endmodule
