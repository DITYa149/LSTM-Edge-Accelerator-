`timescale 1ns/1ps
// =============================================================================
// Buffers_ROM_TB.v - weight_rom, input_buffer, output_buffer
//   NOTE: the simulator prints one '$readmemh: Unable to open this_file_does_not_exist.mem' message
//         at time 0. That is EXPECTED - it is the deliberate missing-file test (ROM must read 0, not X).
// =============================================================================
`ifndef MEM_DIR
  `define MEM_DIR "mem/"
`endif
module Buffers_ROM_TB;
    localparam MEM_DIR = `MEM_DIR;
    reg clk = 0, rst = 1;
    always #5 clk = ~clk;
    integer errors = 0;

    // ---------------------------------------------------------------- weight ROM
    reg         rom_en = 1;
    reg  [5:0]  rom_addr = 0;
    wire signed [15:0] rom_q, rom_missing_q;
    reg  signed [15:0] ref_rom [0:63];
    weight_rom #(.ADDR_WIDTH(6), .DEPTH(64), .MEM_FILE({MEM_DIR, "w_forget.mem"})) u_rom (.en(rom_en), .addr(rom_addr), .data_out(rom_q));
    weight_rom #(.ADDR_WIDTH(6), .DEPTH(64), .MEM_FILE("this_file_does_not_exist.mem")) u_rom_missing (.en(1'b1), .addr(rom_addr), .data_out(rom_missing_q));

    // ---------------------------------------------------------------- input buffer
    reg         ib_we = 0, ib_re = 0;
    reg  [5:0]  ib_waddr = 0, ib_raddr = 0;
    reg  signed [15:0] ib_wdata = 0;
    wire signed [15:0] ib_q;
    reg  signed [15:0] ref_in [0:39];
    input_buffer #(.DEPTH(40), .MEM_FILE({MEM_DIR, "input_case_000.mem"})) u_ib (
        .clk(clk), .rst(rst), .write_en(ib_we), .write_addr(ib_waddr), .write_data(ib_wdata),
        .read_en(ib_re), .read_addr(ib_raddr), .data_out(ib_q));

    // ---------------------------------------------------------------- output buffer
    reg         ob_clear = 0, ob_we = 0, ob_re = 0;
    reg  [63:0] ob_din = 0;
    reg  [3:0]  ob_raddr = 0;
    wire [63:0] ob_q;
    wire [3:0]  ob_count;
    output_buffer #(.DEPTH(10), .ADDR_WIDTH(4)) u_ob (
        .clk(clk), .rst(rst), .clear(ob_clear), .write_en(ob_we), .prediction_in(ob_din),
        .read_en(ob_re), .read_addr(ob_raddr), .prediction_out(ob_q), .sample_count(ob_count));

    task ob_write(input [63:0] v);
        begin @(negedge clk); ob_we = 1; ob_din = v; @(negedge clk); ob_we = 0; end
    endtask
    task ob_read_check(input [3:0] a, input [63:0] want, input [255:0] name);
        begin
            @(negedge clk); ob_re = 1; ob_raddr = a;
            @(negedge clk); ob_re = 0;
            if (ob_q !== want) begin errors = errors + 1; $display("FAIL: %0s: out buffer[%0d] = %h expected %h", name, a, ob_q, want); end
        end
    endtask

    integer i;
    reg [63:0] held;
    initial begin
        $readmemh({MEM_DIR, "w_forget.mem"}, ref_rom);
        $readmemh({MEM_DIR, "input_case_000.mem"}, ref_in);

        repeat (3) @(negedge clk);
        rst = 0;

        // ---- ROM
        for (i = 0; i < 64; i = i + 1) begin
            rom_addr = i; #1;
            if (rom_q !== ref_rom[i]) begin errors = errors + 1; $display("FAIL: ROM[%0d] = %h expected %h", i, rom_q, ref_rom[i]); end
            if (rom_missing_q !== 16'sd0) begin errors = errors + 1; $display("FAIL: missing-file ROM[%0d] = %h (expected 0, not X)", i, rom_missing_q); end
        end
        rom_en = 0; rom_addr = 5; #1;
        if (rom_q !== 16'sd0) begin errors = errors + 1; $display("FAIL: ROM en=0 gave %h", rom_q); end
        rom_en = 1;
        $display("weight_rom: 64 words match file, missing file reads 0 (no X), en=0 gives 0");

        // ---- input buffer: preload visible, 1-cycle latency
        for (i = 0; i < 40; i = i + 1) begin
            @(negedge clk); ib_re = 1; ib_raddr = i;
            @(negedge clk); ib_re = 0;
            if (ib_q !== ref_in[i]) begin errors = errors + 1; $display("FAIL: input_buffer[%0d] = %h expected %h", i, ib_q, ref_in[i]); end
        end
        // write then read back
        @(negedge clk); ib_we = 1; ib_waddr = 7; ib_wdata = 16'shBEEF;
        @(negedge clk); ib_we = 0;
        @(negedge clk); ib_re = 1; ib_raddr = 7;
        @(negedge clk); ib_re = 0;
        if (ib_q !== 16'shBEEF) begin errors = errors + 1; $display("FAIL: input_buffer write/read got %h", ib_q); end
        // read_en low holds data_out
        @(negedge clk); ib_raddr = 8;
        @(negedge clk);
        if (ib_q !== 16'shBEEF) begin errors = errors + 1; $display("FAIL: data_out changed with read_en low"); end
        // simultaneous write+read of the same address returns the OLD value
        held = ref_in[12];
        @(negedge clk); ib_we = 1; ib_waddr = 12; ib_wdata = 16'sh1234; ib_re = 1; ib_raddr = 12;
        @(negedge clk); ib_we = 0; ib_re = 0;
        if (ib_q !== ref_in[12]) begin errors = errors + 1; $display("FAIL: same-address write+read returned %h expected old %h", ib_q, ref_in[12]); end
        @(negedge clk); ib_re = 1; ib_raddr = 12;
        @(negedge clk); ib_re = 0;
        if (ib_q !== 16'sh1234) begin errors = errors + 1; $display("FAIL: write at same-address read was lost: %h", ib_q); end
        // async reset clears data_out only, memory survives
        @(negedge clk); rst = 1; #1;
        if (ib_q !== 16'sd0) begin errors = errors + 1; $display("FAIL: reset did not clear data_out"); end
        @(negedge clk); rst = 0;
        @(negedge clk); ib_re = 1; ib_raddr = 7;
        @(negedge clk); ib_re = 0;
        if (ib_q !== 16'shBEEF) begin errors = errors + 1; $display("FAIL: memory content lost over reset"); end
        $display("input_buffer: preload, latency, write/read, hold, same-address, reset behaviour checked");

        // ---- output buffer
        if (ob_count !== 4'd0) begin errors = errors + 1; $display("FAIL: out_count after reset = %0d", ob_count); end
        ob_write(64'h1111_0000_0000_0001);
        ob_write(64'h2222_0000_0000_0002);
        ob_write(64'h3333_0000_0000_0003);
        if (ob_count !== 4'd3) begin errors = errors + 1; $display("FAIL: count %0d expected 3", ob_count); end
        ob_read_check(9, 64'h3333_0000_0000_0003, "newest at DEPTH-1");
        ob_read_check(8, 64'h2222_0000_0000_0002, "second newest");
        ob_read_check(7, 64'h1111_0000_0000_0001, "oldest of three");
        ob_read_check(6, 64'd0, "unwritten entry is zero");
        ob_read_check(4'd12, 64'd0, "address >= DEPTH is ignored (output unchanged)");
        for (i = 4; i < 14; i = i + 1) ob_write({16'hAAAA, 32'd0, i[15:0]});
        if (ob_count !== 4'd10) begin errors = errors + 1; $display("FAIL: count did not saturate at 10 (%0d)", ob_count); end
        ob_read_check(9, {16'hAAAA, 32'd0, 16'd13}, "newest after overflow");
        ob_read_check(0, {16'hAAAA, 32'd0, 16'd4},  "oldest kept after overflow (entries 0..3 dropped)");
        // read during write returns the pre-shift value
        @(negedge clk); ob_we = 1; ob_din = 64'hDEAD_BEEF_0000_0001; ob_re = 1; ob_raddr = 9;
        @(negedge clk); ob_we = 0; ob_re = 0;
        if (ob_q !== {16'hAAAA, 32'd0, 16'd13}) begin errors = errors + 1; $display("FAIL: read-during-write returned %h", ob_q); end
        // clear
        @(negedge clk); ob_clear = 1;
        @(negedge clk); ob_clear = 0;
        if (ob_count !== 4'd0) begin errors = errors + 1; $display("FAIL: clear left count %0d", ob_count); end
        for (i = 0; i < 10; i = i + 1) ob_read_check(i, 64'd0, "cleared");
        $display("output_buffer: shift order, saturating count, bounds, read-during-write, clear checked");

        if (errors == 0) $display("ALL BUFFER/ROM TESTS PASSED");
        else             $display("BUFFER/ROM TESTS FAILED: %0d", errors);
        $finish;
    end
endmodule
