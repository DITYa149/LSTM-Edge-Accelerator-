`timescale 1ns/1ps
// =============================================================================
// LUT_TB.v - SELF-CHECKING test of activation_lut (the old bench only printed values)
//   * enable = 0 gives 0 for both functions
//   * every one of the 65536 input codes, sigmoid and tanh, compared with an independent
//     real-number reference:  x_grid = -8 + idx/64,  expected = round(f(x_grid) * 4096)
//     (tolerance TOL LSB, default 1, to allow for the rounding used when the table was made)
//   * monotonic non-decreasing and range check over the whole input range
//   * end-point clamping and the sigmoid(0) = 0x0800 / tanh(0) = 0 anchors
// Compile-time: -DMEM_DIR="\"golden_reference/synthetic/\""   -DTOL=1
// =============================================================================
`ifndef MEM_DIR
  `define MEM_DIR "mem/"
`endif
`ifndef TOL
  `define TOL 1
`endif

module LUT_TB;
    localparam MEM_DIR = `MEM_DIR;

    reg  signed [15:0] din;
    reg                sel, en;
    wire signed [15:0] dout;

    activation_lut #(.SIGMOID_FILE({MEM_DIR, "sigmoid_lut.mem"}),
                     .TANH_FILE   ({MEM_DIR, "tanh_lut.mem"})) dut (
        .data_in(din), .activation_sel(sel), .enable(en), .data_out(dout));

    function integer ref_idx;
        input signed [15:0] code;
        real p;
        integer idx;
        begin
            p = (code / 4096.0 + 8.0) * 64.0;
            idx = $floor(p + 0.5);
            if (idx < 0) idx = 0;
            if (idx > 1024) idx = 1024;
            ref_idx = idx;
        end
    endfunction

    function integer ref_val;
        input integer idx;
        input integer is_sigmoid;
        real xg, fv, s;
        integer r;
        begin
            xg = -8.0 + idx / 64.0;
            fv = is_sigmoid ? 1.0 / (1.0 + $exp(-xg)) : $tanh(xg);
            s  = fv * 4096.0;
            r  = (s >= 0.0) ? $floor(s + 0.5) : -$floor(-s + 0.5);
            if (r > 32767) r = 32767;
            if (r < -32768) r = -32768;
            ref_val = r;
        end
    endfunction

    integer errors, i, f, want, diff, max_diff [0:1];
    integer prev_val;
    integer non_mono, out_of_range;

    initial begin
        errors = 0; max_diff[0] = 0; max_diff[1] = 0;

        // ---- enable = 0
        en = 0;
        for (f = 0; f < 2; f = f + 1) begin
            sel = f;
            for (i = -32768; i < 32768; i = i + 8191) begin
                din = i; #1;
                if (dout !== 16'sd0) begin errors = errors + 1; $display("FAIL: enable=0 sel=%0d din=%0d gave %0d", f, i, dout); end
            end
        end
        $display("enable=0 forces output to 0: %s", errors == 0 ? "PASS" : "FAIL");

        // ---- full sweep
        en = 1;
        for (f = 0; f < 2; f = f + 1) begin             // f=1 sigmoid, f=0 tanh
            sel = f;
            non_mono = 0; out_of_range = 0; prev_val = -40000;
            for (i = -32768; i < 32768; i = i + 1) begin
                din = i; #1;
                want = ref_val(ref_idx(din), f);
                diff = dout - want; if (diff < 0) diff = -diff;
                if (diff > max_diff[f]) max_diff[f] = diff;
                if (diff > `TOL) begin
                    errors = errors + 1;
                    if (errors < 12) $display("FAIL: %0s din=%0d (%h): got %0d expected %0d", f ? "sigmoid" : "tanh", i, din, dout, want);
                end
                if (dout < prev_val) non_mono = non_mono + 1;
                prev_val = dout;
                if (f == 1 && (dout < 0 || dout > 4096))      out_of_range = out_of_range + 1;
                if (f == 0 && (dout < -4096 || dout > 4096))  out_of_range = out_of_range + 1;
            end
            errors = errors + non_mono + out_of_range;
            $display("%0s: all 65536 codes checked, max |error| vs real math = %0d LSB, non-monotonic steps = %0d, out-of-range = %0d",
                     f ? "sigmoid" : "tanh   ", max_diff[f], non_mono, out_of_range);
        end

        // ---- anchors and clamping
        sel = 1; din = 0; #1;
        if (dout !== 16'h0800) begin errors = errors + 1; $display("FAIL: sigmoid(0) = %h, expected 0800", dout); end
        sel = 0; din = 0; #1;
        if (dout !== 16'h0000) begin errors = errors + 1; $display("FAIL: tanh(0) = %h, expected 0000", dout); end
        sel = 0; din = 16'sh7fff; #1; if (dout < 16'sd4090) begin errors = errors + 1; $display("FAIL: tanh(+max) = %0d", dout); end
        sel = 0; din = 16'sh8000; #1; if (dout > -16'sd4090) begin errors = errors + 1; $display("FAIL: tanh(-max) = %0d", dout); end
        sel = 1; din = 16'sh8000; #1; if (dout > 16'sd5)     begin errors = errors + 1; $display("FAIL: sigmoid(-8) = %0d", dout); end

        if (errors == 0) $display("RESULT      : PASS");
        else             $display("RESULT      : FAIL (%0d)", errors);
        $finish;
    end
endmodule
