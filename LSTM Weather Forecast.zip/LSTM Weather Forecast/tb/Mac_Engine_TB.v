`timescale 1ns/1ps
// =============================================================================
// Mac_Engine_TB.v
//   Part 1: your original directed tests (bias + products, half-way rounding, saturation)
//   Part 2: 20-element dot product driven the way the sequencer does it (start = 1-cycle pulse)
//   Part 3: documents the contract - start held as a LEVEL breaks accumulation
//   Part 4: 500 random dot products (random length 1..20, full-range operands), back-to-back,
//           compared with an independent behavioural reference
// =============================================================================
module mac_engine_tb;

    reg clk;
    reg rst;
    reg start;
    reg valid;
    reg last;
    reg signed [15:0] data_in;
    reg signed [15:0] weight_in;
    reg signed [15:0] bias_in;

    wire signed [39:0] result;
    wire done;

    integer errors;

    mac_engine #(.DATA_WIDTH(16), .ACC_WIDTH(40), .FRACTIONAL_BITS(12)) dut (
        .clk(clk), .rst(rst), .start(start), .valid(valid), .last(last),
        .data_in(data_in), .weight_in(weight_in), .bias_in(bias_in),
        .result(result), .done(done)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    task check_result;
        input [15:0] expected;
        input [255:0] test_name;
        begin
            if (done !== 1'b1) begin
                $display("FAIL: %0s: done was not asserted", test_name);
                errors = errors + 1;
            end
            if (result[15:0] !== expected) begin
                $display("FAIL: %0s: expected 0x%04h, got 0x%04h", test_name, expected, result[15:0]);
                errors = errors + 1;
            end else begin
                $display("PASS: %0s: result=0x%04h", test_name, result[15:0]);
            end
        end
    endtask

    task run_single_product;
        input signed [15:0] operand;
        input signed [15:0] weight;
        input signed [15:0] bias;
        input [15:0] expected;
        input [255:0] test_name;
        begin
            @(negedge clk);
            start = 1'b1; valid = 1'b1; last = 1'b1;
            data_in = operand; weight_in = weight; bias_in = bias;
            @(posedge clk);
            #1;
            check_result(expected, test_name);
            @(negedge clk);
            start = 1'b0; valid = 1'b0; last = 1'b0;
        end
    endtask

    // ---------------- independent reference model -----------------------------------
    function [15:0] ref_round_sat;
        input signed [63:0] acc;
        reg [63:0] mag, r;
        begin
            mag = (acc < 0) ? -acc : acc;
            r   = (mag + 64'd2048) >> 12;
            if (acc >= 0) ref_round_sat = (r > 64'd32767) ? 16'h7fff : r[15:0];
            else          ref_round_sat = (r > 64'd32768) ? 16'h8000 : (-r[15:0]);
        end
    endfunction

    reg signed [15:0] dvec [0:19];
    reg signed [15:0] wvec [0:19];
    reg signed [15:0] bvec;

    // drive one pass; start_as_level selects the (wrong) level-style start
    task run_pass;
        input integer len;
        input        start_as_level;
        input [15:0] expected;
        input [255:0] name;
        input        report_only;
        integer k;
        begin
            for (k = 0; k < len; k = k + 1) begin
                @(negedge clk);
                valid     = 1'b1;
                last      = (k == len - 1);
                start     = start_as_level ? 1'b1 : (k == 0);
                data_in   = dvec[k];
                weight_in = wvec[k];
                bias_in   = bvec;
                if (k < len - 1) begin
                    @(posedge clk); #1;
                    if (done !== 1'b0) begin
                        $display("FAIL: %0s: done asserted before last element", name);
                        errors = errors + 1;
                    end
                end
            end
            @(posedge clk); #1;
            if (report_only) begin
                $display("INFO: %0s: result=0x%04h (correct would be 0x%04h)%s", name, result[15:0], expected,
                         (result[15:0] !== expected) ? "  -> start as a level is WRONG, as documented" : "");
            end else if (done !== 1'b1 || result[15:0] !== expected) begin
                $display("FAIL: %0s: expected 0x%04h got 0x%04h done=%b", name, expected, result[15:0], done);
                errors = errors + 1;
            end
            // back-to-back: leave valid/start low only if the caller waits; here we simply deassert
            @(negedge clk);
            valid = 1'b0; last = 1'b0; start = 1'b0;
        end
    endtask

    integer i, k, n, seed;
    reg [15:0] exp16;
    reg signed [63:0] acc;

    initial begin
        errors = 0; seed = 32'h1234abcd;
        rst = 1'b1; start = 1'b0; valid = 1'b0; last = 1'b0;
        data_in = 0; weight_in = 0; bias_in = 0;

        repeat (2) @(posedge clk);
        @(negedge clk);
        rst = 1'b0;

        // ---------------- Part 1: original tests -----------------------------------
        // Bias 1.0 + (1.5 * 2.0) + (1.0 * 0.5) = 4.5
        @(negedge clk);
        start = 1'b1; valid = 1'b1; last = 1'b0;
        bias_in = 16'h1000; data_in = 16'h1800; weight_in = 16'h2000;
        @(posedge clk); #1;
        if (done !== 1'b0) begin
            $display("FAIL: intermediate MAC cycle asserted done");
            errors = errors + 1;
        end
        @(negedge clk);
        start = 1'b0; valid = 1'b1; last = 1'b1;
        bias_in = 16'h0000; data_in = 16'h1000; weight_in = 16'h0800;
        @(posedge clk); #1;
        check_result(16'h4800, "bias plus two products");
        @(negedge clk);
        start = 1'b0; valid = 1'b0; last = 1'b0;

        run_single_product(16'h0001, 16'h0800, 16'h0000, 16'h0001, "positive half-way rounding");
        run_single_product(-16'sd1,  16'h0800, 16'h0000, 16'hffff, "negative half-way rounding");
        run_single_product(16'h7000, 16'h2000, 16'h0000, 16'h7fff, "positive saturation");
        run_single_product(16'h9000, 16'h2000, 16'h0000, 16'h8000, "negative saturation");

        // ---------------- Part 2: sequencer-style dot product --------------------------
        // 4 products of 1.0 * 1.0 with bias 0  ->  4.0 = 0x4000
        for (k = 0; k < 4; k = k + 1) begin dvec[k] = 16'h1000; wvec[k] = 16'h1000; end
        bvec = 16'h0000;
        run_pass(4, 1'b0, 16'h4000, "4 x (1.0*1.0), start pulse", 1'b0);

        // 20 elements: x part 4 values * 0.5 ... bias -0.25 : 20 * (0.5*0.5) - 0.25 = 4.75 = 0x4C00
        for (k = 0; k < 20; k = k + 1) begin dvec[k] = 16'h0800; wvec[k] = 16'h0800; end
        bvec = 16'hFC00;
        run_pass(20, 1'b0, 16'h4C00, "20-element pass with bias, start pulse", 1'b0);

        // ---------------- Part 3: contract documentation -------------------------------
        for (k = 0; k < 4; k = k + 1) begin dvec[k] = 16'h1000; wvec[k] = 16'h1000; end
        bvec = 16'h0000;
        run_pass(4, 1'b1, 16'h4000, "4 x (1.0*1.0), start held as LEVEL", 1'b1);

        // ---------------- Part 4: randomised ---------------------------------------------
        for (i = 0; i < 500; i = i + 1) begin
            n = 1 + ({$random(seed)} % 20);
            acc = 0;
            bvec = $random(seed);
            if (i % 5 == 0) bvec = (i % 10 == 0) ? 16'sh7fff : 16'sh8000;      // extreme biases
            for (k = 0; k < n; k = k + 1) begin
                dvec[k] = $random(seed);
                wvec[k] = $random(seed);
                if (i % 7 == 0) begin dvec[k] = dvec[k] >>> 6; wvec[k] = wvec[k] >>> 6; end  // small values: no saturation
            end
            acc = $signed({{48{bvec[15]}}, bvec}) <<< 12;
            for (k = 0; k < n; k = k + 1)
                acc = acc + $signed(dvec[k]) * $signed(wvec[k]);
            exp16 = ref_round_sat(acc);
            run_pass(n, 1'b0, exp16, "random dot product", 1'b0);
        end
        $display("random dot products: 500 run");

        if (errors == 0)
            $display("ALL MAC TESTS PASSED");
        else
            $display("MAC TESTS FAILED: %0d error(s)", errors);

        $finish;
    end

endmodule
