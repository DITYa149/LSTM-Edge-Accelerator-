`timescale 1ns/1ps
`include "summary_thresholds.vh"
module Prediction_TB;
    reg [63:0] previous_sample, prediction;
    wire [1:0] state;
    wire [13:0] flags;
    integer errors;
    rule_based_summary dut(.previous_sample(previous_sample), .prediction(prediction), .state(state), .flags(flags));

    function [63:0] pack4;
        input signed [15:0] t;
        input signed [15:0] s;
        input signed [15:0] h;
        input signed [15:0] g;
        begin
            pack4 = {g, h, s, t};
        end
    endfunction

    task check;
        input [63:0] prev;
        input [63:0] pred;
        input [1:0] wanted;
        input [255:0] label;
        begin
            previous_sample = prev; prediction = pred; #1;
            if (state !== wanted) begin
                errors = errors + 1;
                $display("FAIL %0s state=%0d expected=%0d flags=%h", label, state, wanted, flags);
            end else $display("PASS %0s", label);
        end
    endtask

    initial begin
        errors = 0; previous_sample = 0; prediction = 0;
        check(pack4(0,0,0,0), pack4(0,0,0,0), 0, "stable");
        check(pack4(`P_REDO_THR_TREND,0,0,0), pack4(0,0,0,0), 0, "trend threshold boundary is stable");
        check(pack4(`P_REDO_THR_TREND+1,0,0,0), pack4(0,0,0,0), 1, "temperature drop => worsening");
        check(pack4(0,0,0,0), pack4(-(`P_REDO_THR_HAZARD+1),0,0,0), 2, "cold temperature => hazardous");
        check(pack4(0,0,0,0), pack4(0,-(`P_REDO_THR_HAZARD+1),0,0), 2, "low solar => hazardous");
        check(pack4(0,0,0,0), pack4(0,0,(`P_REDO_THR_HAZARD+1),0), 2, "high humidity => hazardous");
        check(pack4(0,0,0,0), pack4(0,0,0,(`P_REDO_THR_HAZARD+1)), 2, "high gas => hazardous");
        if (errors == 0) $display("SUMMARY TESTS PASS");
        else $display("SUMMARY TESTS FAIL (%0d)", errors);
        $finish;
    end
endmodule
