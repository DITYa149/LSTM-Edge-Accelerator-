`timescale 1ns/1ps
// =============================================================================
// Prelu_TB.v - scalar PReLU: directed corner cases + 20000 random vectors
// =============================================================================
module Prelu_TB;
    reg  signed [15:0] x, a;
    wire signed [15:0] y;
    prelu dut (.data_in(x), .alpha(a), .data_out(y));

    function signed [15:0] ref_prelu;
        input signed [15:0] xin;
        input signed [15:0] ain;
        reg signed [63:0] p;
        reg [63:0] mag, r;
        begin
            if (xin >= 0) ref_prelu = xin;
            else begin
                p = $signed(ain) * $signed(xin);
                mag = (p < 0) ? -p : p;
                r = (mag + 64'd2048) >> 12;
                if (p >= 0) ref_prelu = (r > 64'd32767) ? 16'sh7fff : r[15:0];
                else        ref_prelu = (r > 64'd32768) ? 16'sh8000 : (-r[15:0]);
            end
        end
    endfunction

    integer errors, n, seed;
    reg signed [15:0] expv;

    task check;
        input signed [15:0] xin;
        input signed [15:0] ain;
        input signed [15:0] want;
        input [255:0] name;
        begin
            x = xin; a = ain; #1;
            if (y !== want) begin
                errors = errors + 1;
                $display("FAIL: %0s: x=%h alpha=%h -> %h, expected %h", name, xin, ain, y, want);
            end else
                $display("PASS: %0s: x=%h alpha=%h -> %h", name, xin, ain, y);
        end
    endtask

    initial begin
        errors = 0; seed = 7;
        check(16'sh1000, 16'sh0400, 16'sh1000, "positive passes through");
        check(16'sh0000, 16'sh0400, 16'sh0000, "zero passes through");
        check(16'sh7fff, 16'sh0400, 16'sh7fff, "max positive passes through");
        check(16'shF000, 16'sh0400, 16'shFC00, "-1.0 * 0.25 = -0.25");
        check(16'shF000, 16'sh1000, 16'shF000, "alpha = 1.0 keeps -1.0");
        check(16'shF000, 16'sh0000, 16'sh0000, "alpha = 0 -> ReLU");
        check(16'sh8000, 16'sh0400, 16'shE000, "most negative * 0.25 = -2.0");
        check(16'shA000, 16'sh2000, 16'sh8000, "negative saturation (-6.0 * 2.0)");
        check(16'shFFFF, 16'sh0800, 16'shFFFF, "-1 LSB * 0.5 rounds away from zero");
        check(16'shFFFF, 16'sh0400, 16'sh0000, "-1 LSB * 0.25 rounds to 0");
        check(16'shF000, 16'shF000, 16'sh1000, "negative alpha: -1.0 * -1.0 = +1.0");
        check(16'sh8000, 16'sh8000, 16'sh7fff, "most-neg * most-neg saturates positive");
        for (n = 0; n < 20000; n = n + 1) begin
            x = $random(seed); a = (n % 3 == 0) ? $random(seed) : ($random(seed) & 16'h1FFF);
            #1;
            expv = ref_prelu(x, a);
            if (y !== expv) begin
                errors = errors + 1;
                if (errors < 10) $display("FAIL random: x=%h a=%h got %h exp %h", x, a, y, expv);
            end
        end
        $display("PReLU random: 20000 vectors");
        if (errors == 0) $display("ALL PRELU TESTS PASSED");
        else             $display("PRELU TESTS FAILED: %0d", errors);
        $finish;
    end
endmodule
