`timescale 1ns/1ps
// =============================================================================
// ElementWise_Random_TB.v - 20000 random / corner vectors for elementwise_combine
//   (complements your directed ElementWise_TB.v; reference is written independently)
// =============================================================================
module ElementWise_Random_TB;
    reg signed [15:0] f, i_g, g, o, c_prev, th;
    wire signed [15:0] c_next, h_next;

    elementwise_combine dut (.forget_gate(f), .input_gate(i_g), .candidate_gate(g), .output_gate(o),
                             .cell_prev(c_prev), .tanh_cell_next(th), .cell_next(c_next), .hidden_next(h_next));

    function signed [15:0] ref_qmul;
        input signed [15:0] a;
        input signed [15:0] b;
        reg signed [63:0] p;
        reg [63:0] mag, r;
        begin
            p = $signed(a) * $signed(b);
            mag = (p < 0) ? -p : p;
            r = (mag + 64'd2048) >> 12;
            if (p >= 0) ref_qmul = (r > 64'd32767) ? 16'sh7fff : r[15:0];
            else        ref_qmul = (r > 64'd32768) ? 16'sh8000 : (-r[15:0]);
        end
    endfunction

    function signed [15:0] ref_sat;
        input signed [31:0] v;
        begin
            ref_sat = (v > 32767) ? 16'sh7fff : (v < -32768) ? 16'sh8000 : v[15:0];
        end
    endfunction

    integer n, seed, errors, sat_pos, sat_neg;
    reg signed [15:0] exp_c, exp_h;
    reg signed [31:0] sum;

    function signed [15:0] rnd;
        input integer mode;
        input integer s;
        integer r;
        begin
            r = $random(seed);
            case (mode)
                0: rnd = r;                                  // full range
                1: rnd = r & 16'h0FFF;                       // 0 .. 1.0
                2: rnd = (r & 16'h1FFF) - 16'sd4096;         // -1.0 .. +1.0
                3: rnd = (r[0]) ? 16'sh7fff : 16'sh8000;     // extremes
                default: rnd = r;
            endcase
        end
    endfunction

    integer m;
    initial begin
        errors = 0; seed = 99; sat_pos = 0; sat_neg = 0;
        for (n = 0; n < 20000; n = n + 1) begin
            m = n % 4;
            f = rnd(m, 0); i_g = rnd(m, 0); g = rnd(m, 0); o = rnd(m, 0);
            c_prev = rnd((m + 1) % 4, 0); th = rnd((m + 2) % 4, 0);
            #1;
            sum   = ref_qmul(f, c_prev) + ref_qmul(i_g, g);
            exp_c = ref_sat(sum);
            exp_h = ref_qmul(o, th);
            if (sum > 32767) sat_pos = sat_pos + 1;
            if (sum < -32768) sat_neg = sat_neg + 1;
            if (c_next !== exp_c || h_next !== exp_h) begin
                errors = errors + 1;
                if (errors < 10)
                    $display("FAIL f=%h i=%h g=%h o=%h c=%h th=%h : c_next %h (exp %h)  h_next %h (exp %h)",
                             f, i_g, g, o, c_prev, th, c_next, exp_c, h_next, exp_h);
            end
        end
        $display("element-wise random: 20000 vectors, cell-sum saturated high %0d / low %0d times", sat_pos, sat_neg);
        if (errors == 0) $display("ALL ELEMENT-WISE RANDOM TESTS PASSED");
        else             $display("ELEMENT-WISE RANDOM TESTS FAILED: %0d", errors);
        $finish;
    end
endmodule
