"""Python equivalent of rtl/Prediction.v; arrays use [temperature, solar, humidity, gas]."""
import numpy as np

STABLE, WORSENING, HAZARDOUS = 0, 1, 2
STATE_NAMES = {STABLE: "STABLE", WORSENING: "WORSENING", HAZARDOUS: "HAZARDOUS"}


def classify_environment(input_window, prediction, trend_threshold=1.0, hazard_threshold=2.0):
    """Classify one next-hour prediction relative to the newest sample in its window."""
    input_window = np.asarray(input_window, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    if input_window.shape != (10, 4):
        raise ValueError("input_window must have shape (10, 4)")
    if prediction.shape != (4,):
        raise ValueError("prediction must have shape (4,)")
    previous = input_window[-1]
    temp_drop = float(previous[0] - prediction[0])
    solar_drop = float(previous[1] - prediction[1])
    gas_rise = float(prediction[3] - previous[3])
    flags = {
        "sharp_cooling": temp_drop > trend_threshold,
        "solar_dimming": solar_drop > trend_threshold,
        "gas_buildup": gas_rise > trend_threshold,
        "temperature_hazard": prediction[0] < -hazard_threshold,
        "solar_hazard": prediction[1] < -hazard_threshold,
        "humidity_hazard": abs(float(prediction[2])) > hazard_threshold,
        "gas_hazard": prediction[3] > hazard_threshold,
    }
    flags["hazard_condition"] = any(flags[k] for k in (
        "temperature_hazard", "solar_hazard", "humidity_hazard", "gas_hazard"))
    if flags["hazard_condition"]:
        state = HAZARDOUS
    elif flags["sharp_cooling"] or flags["solar_dimming"] or flags["gas_buildup"]:
        state = WORSENING
    else:
        state = STABLE
    return state, STATE_NAMES[state], flags
