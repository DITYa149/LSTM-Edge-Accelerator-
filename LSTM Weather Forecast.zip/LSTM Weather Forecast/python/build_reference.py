"""Export the trained NumPy checkpoint into P_Redo's fixed-point RTL contract."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
WEIGHT_KEYS = ("W_lstm", "U_lstm", "b_lstm", "W_dense", "b_dense", "alpha_prelu", "W_output", "b_output")
GATES = ("forget", "input", "candidate", "output")
F = 12
SCALE = 1 << F
WIDTH = 16
MIN_CODE = -(1 << (WIDTH - 1))
MAX_CODE = (1 << (WIDTH - 1)) - 1
SAT_EVENTS = 0


def round_away(x):
    x = np.asarray(x, dtype=np.float64)
    return np.where(x >= 0, np.floor(x + 0.5), np.ceil(x - 0.5)).astype(np.int64)


def sat(x):
    global SAT_EVENTS
    values = np.asarray(x, dtype=np.int64)
    SAT_EVENTS += int(np.count_nonzero((values < MIN_CODE) | (values > MAX_CODE)))
    return np.clip(values, MIN_CODE, MAX_CODE).astype(np.int64)


def q(x):
    return sat(round_away(np.asarray(x) * SCALE))


def qshift(x):
    x = np.asarray(x, dtype=np.int64)
    mag = (np.abs(x) + (SCALE >> 1)) >> F
    return np.where(x < 0, -mag, mag).astype(np.int64)


def qmul(a, b):
    return sat(qshift(np.asarray(a, dtype=np.int64) * np.asarray(b, dtype=np.int64)))


def write_words(path: Path, values, width=16):
    path.parent.mkdir(parents=True, exist_ok=True)
    mask = (1 << width) - 1
    digits = (width + 3) // 4
    flat = np.asarray(values, dtype=np.int64).reshape(-1)
    path.write_text("".join(f"{int(v) & mask:0{digits}X}\n" for v in flat), encoding="ascii")


def write_packed(path: Path, values):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(f"{int(v) & ((1 << 64) - 1):016X}\n" for v in values), encoding="ascii")


def lut_tables():
    grid = np.arange(1025, dtype=np.float64) / 64.0 - 8.0
    sigmoid = q(1.0 / (1.0 + np.exp(-grid)))
    tanh = q(np.tanh(grid))
    return sigmoid, tanh


def lut_apply(code, table):
    code = np.clip(np.asarray(code, dtype=np.int64), -8 * SCALE, 8 * SCALE)
    index = np.clip((code + 8 * SCALE + 32) // 64, 0, 1024)
    return table[index]


def fixed_matmul(a, w, b):
    return sat(qshift(np.asarray(a, dtype=np.int64) @ np.asarray(w, dtype=np.int64)
                      + (np.asarray(b, dtype=np.int64) << F)))


def fixed_forward(x_float, weights, sigmoid, tanh):
    qw = {k: q(weights[k]) for k in WEIGHT_KEYS}
    x = q(x_float)
    h = np.zeros(16, dtype=np.int64)
    c = np.zeros(16, dtype=np.int64)
    h_trace, c_trace = [], []
    for xt in x:
        z = sat(qshift(xt @ qw["W_lstm"] + h @ qw["U_lstm"] + (qw["b_lstm"] << F)))
        zf, zi, zg, zo = np.split(z, 4)
        fg, ig = lut_apply(zf, sigmoid), lut_apply(zi, sigmoid)
        gg, og = lut_apply(zg, tanh), lut_apply(zo, sigmoid)
        c = sat(qmul(fg, c) + qmul(ig, gg))
        h = qmul(og, lut_apply(c, tanh))
        h_trace.append(h.copy())
        c_trace.append(c.copy())
    dense = fixed_matmul(h, qw["W_dense"], qw["b_dense"])
    prelu = np.where(dense >= 0, dense, qmul(qw["alpha_prelu"], dense))
    pred = fixed_matmul(prelu, qw["W_output"], qw["b_output"])
    return x, np.asarray(h_trace), np.asarray(c_trace), pred


def float_forward(x, w):
    h = np.zeros(16, dtype=np.float64)
    c = np.zeros(16, dtype=np.float64)
    ht, ct = [], []
    for xt in np.asarray(x, dtype=np.float64):
        z = xt @ w["W_lstm"] + h @ w["U_lstm"] + w["b_lstm"]
        zf, zi, zg, zo = np.split(z, 4)
        f = 1.0 / (1.0 + np.exp(-np.clip(zf, -80, 80)))
        i = 1.0 / (1.0 + np.exp(-np.clip(zi, -80, 80)))
        g = np.tanh(zg)
        o = 1.0 / (1.0 + np.exp(-np.clip(zo, -80, 80)))
        c = f * c + i * g
        h = o * np.tanh(c)
        ht.append(h.copy())
        ct.append(c.copy())
    dense = h @ w["W_dense"] + w["b_dense"]
    prelu = np.where(dense >= 0, dense, dense * w["alpha_prelu"])
    return np.asarray(ht), np.asarray(ct), prelu @ w["W_output"] + w["b_output"]


def summarize(previous, prediction, trend=1.0, hazard=2.0):
    tdrop = float(previous[0] - prediction[0])
    sdrop = float(previous[1] - prediction[1])
    grise = float(prediction[3] - previous[3])
    hazard_bits = (prediction[0] < -hazard, prediction[1] < -hazard,
                   abs(prediction[2]) > hazard, prediction[3] > hazard)
    flags = int(tdrop > trend) | (int(sdrop > trend) << 1) | (int(grise > trend) << 2)
    for n, bit in enumerate(hazard_bits, start=3):
        flags |= int(bit) << n
    any_hazard = any(hazard_bits)
    flags |= int(any_hazard) << 7
    state = 2 if any_hazard else (1 if flags & 7 else 0)
    return state, flags


def tune_summary_codes(inputs, weights, sigmoid, tanh):
    trend_scores, hazard_scores, previous_rows, prediction_rows = [], [], [], []
    for x in inputs:
        qx, _, _, pred = fixed_forward(x, weights, sigmoid, tanh)
        p = qx[-1] / SCALE
        y = pred / SCALE
        previous_rows.append(p)
        prediction_rows.append(y)
        trend_scores.append(max(p[0] - y[0], p[1] - y[1], y[3] - p[3]))
        hazard_scores.append(max(-y[0], -y[1], abs(y[2]), y[3]))
    trend_scores = np.asarray(trend_scores)
    hazard_scores = np.asarray(hazard_scores)
    tc = sorted(set(min(MAX_CODE - 1, max(0, int(round_away(np.quantile(trend_scores, p) * SCALE))))
                    for p in (0.20, 0.35, 0.50, 0.65, 0.80, 0.90, 0.97)))
    hc = sorted(set(min(MAX_CODE - 1, max(0, int(round_away(np.quantile(hazard_scores, p) * SCALE))))
                    for p in (0.50, 0.65, 0.75, 0.85, 0.92, 0.97, 0.99)))
    best = None
    for tcode in tc:
        for hcode in hc:
            labels = []
            for p, y in zip(previous_rows, prediction_rows):
                state, _ = summarize(p, y, tcode / SCALE, hcode / SCALE)
                labels.append(state)
            counts = np.bincount(labels, minlength=3)
            score = (int(counts.min()), -int(counts.max()))
            if best is None or score > best[0]:
                best = (score, tcode, hcode, counts)
            if np.all(counts > 0) and score == best[0]:
                best = (score, tcode, hcode, counts)
    if best is None or best[0][0] == 0:
        counts = np.zeros(3, dtype=int)
        for p, y in zip(previous_rows, prediction_rows):
            state, _ = summarize(p, y, 1.0, 2.0)
            counts[state] += 1
        return 4096, 8192, counts
    return best[1], best[2], best[3]


def packed_prediction(pred):
    # RTL bus is {gas, humidity, solar, temperature}; Python order is the reverse.
    temp, solar, humidity, gas = [int(v) & 0xFFFF for v in pred]
    return (gas << 48) | (humidity << 32) | (solar << 16) | temp


def export_parameters(weights, mem):
    qw = {k: q(weights[k]) for k in WEIGHT_KEYS}
    for gi, gate in enumerate(GATES):
        sl = slice(gi * 16, (gi + 1) * 16)
        prefix = "gate_output" if gate == "output" else gate
        write_words(mem / f"w_{prefix}.mem", qw["W_lstm"][:, sl].T)
        write_words(mem / f"u_{prefix}.mem", qw["U_lstm"][:, sl].T)
        write_words(mem / f"b_{prefix}.mem", qw["b_lstm"][sl])
    write_words(mem / "w_shared.mem", qw["W_dense"].T)
    write_words(mem / "b_shared.mem", qw["b_dense"])
    write_words(mem / "alpha_prelu.mem", qw["alpha_prelu"])
    head_names = ("temp", "solar", "humidity", "gas")
    for j, name in enumerate(head_names):
        write_words(mem / f"w_{name}.mem", qw["W_output"][:, j])
    write_words(mem / "b_heads.mem", qw["b_output"])


def main():
    global SAT_EVENTS
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", type=Path, default=ROOT / "artifacts" / "best_model_weights.npz")
    ap.add_argument("--inputs", type=Path, default=ROOT / "data" / "X_test.npy")
    ap.add_argument("--targets", type=Path, default=None,
                    help="optional normalized targets; defaults to data/y_test.npy only for the bundled test input")
    ap.add_argument("--normalization", type=Path, default=ROOT / "data" / "mars_normalization_parameters.csv")
    ap.add_argument("--cases", type=int, default=1)
    ap.add_argument("--trend-threshold", type=float, default=None,
                    help="normalized trend threshold; omit to tune for three classes")
    ap.add_argument("--hazard-threshold", type=float, default=None,
                    help="normalized severity threshold; omit to tune for three classes")
    ap.add_argument("--out", type=Path, default=ROOT / "mem")
    args = ap.parse_args()
    if args.cases < 1:
        ap.error("--cases must be at least 1")
    args.out.mkdir(parents=True, exist_ok=True)
    with np.load(args.weights) as z:
        weights = {k: z[k] for k in WEIGHT_KEYS}
    with args.normalization.open(newline="", encoding="utf-8") as f:
        norm_rows = list(csv.DictReader(f))
    norm_mean = np.asarray([float(r["mean"]) for r in norm_rows], dtype=np.float64)
    norm_std = np.asarray([float(r["std"]) for r in norm_rows], dtype=np.float64)
    if norm_mean.shape != (4,) or norm_std.shape != (4,):
        raise ValueError("Normalization CSV must contain four sensor rows with mean/std columns")
    all_inputs = np.load(args.inputs).astype(np.float64)
    bundled_inputs = (ROOT / "data" / "X_test.npy").resolve()
    target_path = args.targets
    if target_path is None and args.inputs.resolve() == bundled_inputs:
        target_path = ROOT / "data" / "y_test.npy"
    all_targets = None if target_path is None else np.load(target_path).astype(np.float64)
    if all_targets is not None and all_targets.shape != (len(all_inputs), 4):
        raise ValueError("Targets must have shape [cases,4] and match the selected input file")
    tune_inputs = np.load(bundled_inputs).astype(np.float64)
    x_cases = all_inputs[:args.cases]
    expected = {"W_lstm": (4, 64), "U_lstm": (16, 64), "b_lstm": (64,),
                "W_dense": (16, 16), "b_dense": (16,), "alpha_prelu": (16,),
                "W_output": (16, 4), "b_output": (4,)}
    for name, shape in expected.items():
        if weights[name].shape != shape:
            raise ValueError(f"{name}: expected {shape}, found {weights[name].shape}")
    stats = {name: {"min": float(np.min(weights[name])), "max": float(np.max(weights[name])),
                    "std": float(np.std(weights[name]))} for name in WEIGHT_KEYS}
    with (args.out / "weight_stats.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(("tensor", "min", "max", "std"))
        for name, row in stats.items():
            writer.writerow((name, row["min"], row["max"], row["std"]))
    metrics = None
    if all_targets is not None:
        float_test_pred = np.asarray([float_forward(x, weights)[2] for x in all_inputs])
        test_err = float_test_pred - all_targets
        metrics = {"test_mse": float(np.mean(test_err ** 2)),
                   "test_rmse": float(np.sqrt(np.mean(test_err ** 2))),
                   "test_mae": float(np.mean(np.abs(test_err))),
                   "sensor_metrics": {n: {
                       "mae_normalized": float(np.mean(np.abs(test_err[:, i]))),
                       "rmse_normalized": float(np.sqrt(np.mean(test_err[:, i] ** 2))),
                       "mae_physical": float(np.mean(np.abs(test_err[:, i] * norm_std[i]))),
                       "rmse_physical": float(np.sqrt(np.mean((test_err[:, i] * norm_std[i]) ** 2)))
                   } for i, n in enumerate(("temperature_C", "solar_radiation_Wm2", "humidity_pct", "co2_concentration_ppm"))}}
        (args.out / "test_metrics.json").write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
        np.savetxt(args.out / "target_case_000.csv", all_targets[0:1], delimiter=",")
    else:
        for stale in (args.out / "test_metrics.json", args.out / "target_case_000.csv"):
            stale.unlink(missing_ok=True)
    if not len(x_cases) or x_cases.shape[1:] != (10, 4):
        raise ValueError("Test inputs must have shape [cases,10,4]")
    SAT_EVENTS = 0
    write_words(args.out / "norm_mean_q16_16.mem", round_away(norm_mean * (1 << 16)), width=32)
    write_words(args.out / "norm_std_q16_16.mem", round_away(norm_std * (1 << 16)), width=32)
    export_parameters(weights, args.out)
    sigmoid, tanh = lut_tables()
    write_words(args.out / "sigmoid_lut.mem", sigmoid)
    write_words(args.out / "tanh_lut.mem", tanh)

    if (args.trend_threshold is None) != (args.hazard_threshold is None):
        ap.error("supply both thresholds or omit both to tune them")
    if args.trend_threshold is None:
        trend_code, hazard_code, class_counts = tune_summary_codes(tune_inputs, weights, sigmoid, tanh)
    else:
        trend_code = int(round_away(args.trend_threshold * SCALE))
        hazard_code = int(round_away(args.hazard_threshold * SCALE))
        if not (0 <= trend_code < MAX_CODE and 0 <= hazard_code < MAX_CODE):
            ap.error("thresholds must be in normalized range [0, 7.9995]")
        class_counts = np.zeros(3, dtype=int)
        for x in tune_inputs:
            qx, _, _, pred = fixed_forward(x, weights, sigmoid, tanh)
            s, _ = summarize(qx[-1] / SCALE, pred / SCALE, trend_code / SCALE, hazard_code / SCALE)
            class_counts[s] += 1
    (ROOT / "rtl" / "summary_thresholds.vh").write_text(
        "// Auto-generated by python/build_reference.py from the quantized test-set distribution.\n"
        "`ifndef P_REDO_THR_TREND\n"
        f"`define P_REDO_THR_TREND {trend_code}\n"
        "`endif\n"
        "`ifndef P_REDO_THR_HAZARD\n"
        f"`define P_REDO_THR_HAZARD {hazard_code}\n"
        "`endif\n", encoding="ascii")

    SAT_EVENTS = 0
    preds, summaries, float_rows = [], [], []
    for n, x in enumerate(x_cases):
        qx, ht, ct, pred = fixed_forward(x, weights, sigmoid, tanh)
        hfloat, cfloat, pred_float = float_forward(x, weights)
        state, flags = summarize(qx[-1] / SCALE, pred / SCALE, trend_code / SCALE, hazard_code / SCALE)
        write_words(args.out / f"input_case_{n:03d}.mem", qx)
        write_words(args.out / "xt.mem", qx)
        write_words(args.out / f"case_{n:03d}_h.mem", ht)
        write_words(args.out / f"case_{n:03d}_c.mem", ct)
        packed = packed_prediction(pred)
        summary_word = ((state & 3) << 14) | flags
        write_packed(args.out / f"expected_pred_case_{n:03d}.mem", [packed])
        write_words(args.out / f"expected_summary_case_{n:03d}.mem", [summary_word])
        write_words(args.out / f"expected_h_case_{n:03d}.mem", ht)
        write_words(args.out / f"expected_c_case_{n:03d}.mem", ct)
        if n == 0:
            write_words(args.out / "ht_ref.mem", ht)
            write_words(args.out / "ct_ref.mem", ct)
            write_words(args.out / "expected_h_case_000.mem", ht)
            write_words(args.out / "expected_c_case_000.mem", ct)
        preds.append(packed)
        summaries.append(summary_word)
        float_rows.append((pred_float, hfloat, cfloat))
    write_packed(args.out / "pred_ref.mem", preds)
    write_words(args.out / "condition_ref.mem", [s >> 14 for s in summaries], width=2)
    float_pred = np.asarray([r[0] for r in float_rows])
    fixed_pred_norm = np.asarray([[((int(code) >> (16 * j)) & 0xFFFF) for j in range(4)] for code in preds], dtype=np.int64)
    fixed_pred_norm = np.where(fixed_pred_norm >= 0x8000, fixed_pred_norm - 0x10000, fixed_pred_norm) / SCALE
    np.savetxt(args.out / "pred_float.csv", float_pred, delimiter=",")
    physical_fixed = fixed_pred_norm * norm_std + norm_mean
    np.savetxt(args.out / "pred_physical.csv", physical_fixed, delimiter=",")
    physical_float = float_pred * norm_std + norm_mean
    errors_norm = fixed_pred_norm - float_pred
    errors_physical = physical_fixed - physical_float
    with (args.out / "error_analysis.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(("sensor", "fixed_normalized", "float_normalized", "abs_error_normalized",
                         "fixed_physical", "float_physical", "abs_error_physical"))
        sensors = ("temperature_C", "solar_radiation_Wm2", "humidity_pct", "co2_concentration_ppm")
        for i in range(len(fixed_pred_norm)):
            for j, sensor in enumerate(sensors):
                writer.writerow((sensor, fixed_pred_norm[i, j], float_pred[i, j], abs(errors_norm[i, j]),
                                 physical_fixed[i, j], physical_float[i, j], abs(errors_physical[i, j])))
    for n, (_, hfloat, cfloat) in enumerate(float_rows):
        np.savetxt(args.out / f"case_{n:03d}_ht_float.csv", hfloat, delimiter=",")
        np.savetxt(args.out / f"case_{n:03d}_ct_float.csv", cfloat, delimiter=",")
    report = {"format": "signed Q4.12, 16-bit, saturating, ties away from zero",
              "architecture": {"sequence": [10, 4], "hidden": 16, "dense": 16, "outputs": 4},
              "feature_order": ["temperature", "solar", "humidity", "gas"],
              "prediction_order_in_bus": ["gas", "humidity", "solar", "temperature"],
              "summary_thresholds_normalized": {"trend": trend_code / SCALE, "hazard": hazard_code / SCALE},
              "normalization": {"mean": norm_mean.tolist(), "std": norm_std.tolist()},
              "weight_statistics": stats,
              "cases": len(x_cases), "summary_codes": {"0": "STABLE", "1": "WORSENING", "2": "HAZARDOUS"},
              "saturations_observed_in_exported_cases": SAT_EVENTS,
              "fixed_predictions_codes": [int(v) for v in preds],
              "max_abs_error_normalized_by_sensor": np.max(np.abs(errors_norm), axis=0).tolist(),
              "max_abs_error_physical_by_sensor": np.max(np.abs(errors_physical), axis=0).tolist(),
              "summary_state_codes": [int(s >> 14) for s in summaries]}
    (args.out / "manifest.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("P_Redo fixed-point reference ready")
    if metrics is not None:
        print(f"float model test MSE={metrics['test_mse']:.6f}, RMSE={metrics['test_rmse']:.6f}, MAE={metrics['test_mae']:.6f} (normalized units)")
    print(f"fixed-point saturation events in exported inference cases = {SAT_EVENTS}")
    print("summary test-set counts [STABLE, WORSENING, HAZARDOUS] = " + str([int(v) for v in class_counts]))
    if np.any(class_counts == 0):
        print("WARNING: selected thresholds do not produce all three labels; tune in python/build_reference.py or pass both thresholds.")
    for i, code in enumerate(preds):
        raw = [int((code >> (16 * j)) & 0xFFFF) for j in range(4)]
        signed = [v - 65536 if v & 0x8000 else v for v in raw]
        normalized = [v / SCALE for v in signed]
        physical = np.asarray(normalized) * norm_std + norm_mean
        state = summaries[i] >> 14
        print(f"case {i}: normalized [temp, solar, humidity, gas] = " + ", ".join(f"{v:.5f}" for v in normalized))
        print("        physical  [temp C, solar W/m2, humidity, gas ppm] = " + ", ".join(f"{v:.3f}" for v in physical))
        print(f"        condition = {('STABLE','WORSENING','HAZARDOUS')[state]} (code {state})")
    print(f"RTL .mem files and float/fixed references: {args.out.resolve()}")


if __name__ == "__main__":
    main()
