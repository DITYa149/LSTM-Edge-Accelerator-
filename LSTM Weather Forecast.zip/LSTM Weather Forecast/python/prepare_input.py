"""Convert 10 raw hourly sensor rows into a normalized [1,10,4] input window."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
FEATURES = ("temperature_C", "solar_radiation_Wm2", "humidity_pct", "co2_concentration_ppm")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True,
                        help="raw CSV with the four sensor columns; rows must be hourly and chronological")
    parser.add_argument("--out", type=Path, default=ROOT / "data" / "custom_window.npy")
    args = parser.parse_args()
    df = pd.read_csv(args.csv)
    missing = [name for name in FEATURES if name not in df.columns]
    if missing:
        parser.error("CSV is missing required columns: " + ", ".join(missing))
    if len(df) < 10:
        parser.error("CSV needs at least 10 hourly rows; the last 10 rows will be used")
    raw = df.loc[:, FEATURES].tail(10).to_numpy(dtype=np.float64)
    with (ROOT / "data" / "mars_normalization_parameters.csv").open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    mean = np.asarray([float(row["mean"]) for row in rows], dtype=np.float64)
    std = np.asarray([float(row["std"]) for row in rows], dtype=np.float64)
    normalized = (raw - mean) / std
    if not np.all(np.isfinite(normalized)):
        parser.error("Input CSV contains non-finite sensor values")
    if np.any(normalized < -8.0) or np.any(normalized >= 8.0):
        parser.error("A normalized input is outside the RTL Q4.12 range [-8,8); check units and normalization")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.save(args.out, normalized[np.newaxis, :, :].astype(np.float32))
    print(f"Saved normalized window shape [1,10,4] to {args.out.resolve()}")
    print("Feature order: temperature_C, solar_radiation_Wm2, humidity_pct, co2_concentration_ppm")


if __name__ == "__main__":
    main()
