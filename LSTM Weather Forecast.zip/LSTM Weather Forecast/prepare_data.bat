@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import pandas, numpy" >nul 2>&1
if errorlevel 1 py -3 -m pip install -r requirements.txt
if errorlevel 1 exit /b 2
py -3 python\generate_sensor_data.py
if errorlevel 1 exit /b 2
py -3 "python\Window Sequence.py"
if errorlevel 1 exit /b 2
echo Synthetic data and sequence windows regenerated under data\.
echo Run run_all.bat --retrain to train the updated model and simulate it.
endlocal
