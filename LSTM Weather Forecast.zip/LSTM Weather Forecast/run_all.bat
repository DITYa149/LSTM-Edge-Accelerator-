@echo off
setlocal
cd /d "%~dp0"

set "INPUT=data\X_test.npy"
set "RETRAIN=0"
:parse_args
if "%~1"=="" goto args_done
if /I "%~1"=="--retrain" set "RETRAIN=1"
if /I "%~1"=="--input" (
    if "%~2"=="" (
        echo Missing file after --input.
        exit /b 2
    )
    set "INPUT=%~2"
    shift
)
if /I "%~1"=="--help" (
    echo Usage: run_all.bat [--input normalized_window.npy] [--retrain]
    echo Default: use the first bundled test window and saved checkpoint.
    exit /b 0
)
shift
goto parse_args

:args_done
py -3 --version >nul 2>&1
if errorlevel 1 (
    echo Python 3 was not found. Install Python 3 and enable the py launcher, then rerun.
    exit /b 2
)

set "WEIGHTS=artifacts\best_model_weights.npz"
if "%RETRAIN%"=="1" (
    echo Retraining the LSTM with L2 regularization and forget bias 1...
    py -3 -c "import tensorflow, pandas, numpy" >nul 2>&1
    if errorlevel 1 (
        echo Training needs TensorFlow, pandas, and NumPy. Install them with:
        echo   py -3 -m pip install tensorflow pandas numpy
        exit /b 2
    )
    py -3 python\LSTM_Core.py
    if errorlevel 1 exit /b 2
    set "WEIGHTS=artifacts\retrained\best_model_weights.npz"
)

py -3 -c "import numpy" >nul 2>&1
if errorlevel 1 (
    echo NumPy is missing. Installing the small inference dependency set...
    py -3 -m pip install -r requirements.txt
    if errorlevel 1 exit /b 2
)

py -3 python\build_reference.py --weights "%WEIGHTS%" --inputs "%INPUT%" --cases 1
if errorlevel 1 exit /b 2

where vsim >nul 2>&1
if errorlevel 1 (
    echo.
    echo Python reference is ready, but ModelSim was not found on PATH.
    echo Install or activate Questa/ModelSim, then run run_all.bat again.
    exit /b 3
)

echo.
echo Running the RTL regression in ModelSim...
vsim -c -do sim/run.do
if errorlevel 1 exit /b 4
findstr /i /c:"RESULT : FAIL" /c:"TESTS FAIL" sim\modelsim.log >nul
if not errorlevel 1 (
    echo RTL regression failed. See sim\modelsim.log.
    exit /b 5
)
findstr /i /c:"RESULT : PASS" sim\modelsim.log >nul
if errorlevel 1 (
    echo No end-to-end PASS marker was found. See sim\modelsim.log.
    exit /b 6
)
echo.
echo PROJECT PASS: fixed-point reference agrees with ModelSim RTL.
echo Physical-unit predictions are in mem\pred_physical.csv.
endlocal
