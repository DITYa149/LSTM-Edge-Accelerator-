transcript file sim/modelsim.log
onerror {quit -f}

if {![file exists work]} {
    vlib work
}

vlog -sv +incdir+rtl rtl/Mac_Engine.v rtl/Element_wise.v rtl/LUT_s_FOR_Activation_Function.v rtl/Prelu.v rtl/Parameter_Rom.v rtl/Input_Buffer.v rtl/Output_Buffer.v rtl/Prediction.v rtl/FSM_Controller.v rtl/Data_Flow.v

vlog -sv +incdir+rtl tb/Mac_Engine_TB.v tb/ElementWise_TB.v tb/ElementWise_Random_TB.v tb/LUT_TB.v tb/Prelu_TB.v tb/Prediction_TB.v tb/Buffers_ROM_TB.v tb/FSM_Controller_TB.v tb/Data_Flow_TB.v

proc run_tb {top} {
    echo ""
    echo "===== $top ====="
    vsim -onfinish stop work.$top
    run -all
    quit -sim
}

run_tb mac_engine_tb
run_tb ElementWise_TB
run_tb ElementWise_Random_TB
run_tb LUT_TB
run_tb Prelu_TB
run_tb Prediction_TB
run_tb Buffers_ROM_TB
run_tb FSM_Controller_TB
run_tb Data_Flow_TB

quit -f